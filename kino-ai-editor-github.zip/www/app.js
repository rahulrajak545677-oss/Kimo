/* KINO — UI demo with an Alight-Motion-style effects engine.
   Replace buildPlan() with backend/LLM output (see README). */
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const ic=n=>`<svg class="i"><use href="#i-${n}"/></svg>`;
const wait=ms=>new Promise(r=>setTimeout(r,ms));
const fmt=s=>{s=Math.max(0,s);return Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0')};
const J=(T,k)=>Math.sin(T*k)*Math.cos(T*k*.37);

const STYLES=[
 ['Cinematic','Slow zooms, glow, film mood','linear-gradient(160deg,#2b2350,#c9a45c)'],
 ['AMV','Fast cuts, shakes, flashes','linear-gradient(160deg,#4a1d5e,#e0457b)'],
 ['Glitch','RGB split, digital tears','linear-gradient(160deg,#0f2f4a,#3ad1c8)'],
 ['Smooth','Soft motion, calm rhythm','linear-gradient(160deg,#1d3b3a,#8bd3a8)'],
 ['Hype','Max energy, beat-locked','linear-gradient(160deg,#5a1f1f,#f2a03d)']
];
const TITLES={Cinematic:'CHAPTER ONE',AMV:'NO LIMITS',Glitch:'SIGNAL LOST',Smooth:'JUST BREATHE',Hype:'LET’S GO'};
const SET={
 Cinematic:{acc:['zoom','glow','push'],tr:['dip','cross','zthru'],look:['vig','grain'],an:'fade',ts:'serif'},
 AMV:{acc:['shake','flash','zoom','rgb'],tr:['whip','glcut','zthru'],look:['vivid'],an:'pop',ts:'bold'},
 Glitch:{acc:['glitch','rgb','shake','wave'],tr:['glcut','whip'],look:['scan','grain'],an:'glitch',ts:'mono'},
 Smooth:{acc:['push','glow','pan'],tr:['cross','dip'],look:['leak'],an:'rise',ts:'serif'},
 Hype:{acc:['shake','flash','zoom','strobe','rgb'],tr:['zthru','whip','spinw'],look:['vivid','vig'],an:'bounce',ts:'neon'}
};
const OPTS=[
 ['cuts','Auto cuts','Trim and cut the footage to the rhythm'],
 ['fx','Effects & animation','Zooms, shakes, glow, glitch, transitions'],
 ['text','Titles & graphics','Animated text and overlays'],
 ['beat','Beat sync','Lock cuts and effects to the music'],
 ['captions','Auto captions','Subtitle the speech in your video']
];
const PROJECTS=[
 ['Anime Edit — Opening','0:24 · AMV','linear-gradient(135deg,#4a1d5e,#e0457b)'],
 ['Night Drive Reel','0:18 · Cinematic','linear-gradient(135deg,#2b2350,#c9a45c)'],
 ['Travel Teaser','0:31 · Smooth','linear-gradient(135deg,#1d3b3a,#8bd3a8)']
];

/* ---------- easing (like keyframe curves) ---------- */
const bez=(a,b,c,d)=>x=>{if(x<=0)return 0;if(x>=1)return 1;let t=x;for(let i=0;i<8;i++){const m=1-t,X=3*m*m*t*a+3*m*t*t*c+t*t*t-x,dX=3*m*m*a+6*m*t*(c-a)+3*t*t*(1-c);if(Math.abs(dX)<1e-6)break;t-=X/dX}const m=1-t;return 3*m*m*t*b+3*m*t*t*d+t*t*t};
const EASE={bezier:bez(.65,0,.35,1),linear:x=>x,scurve:x=>x*x*(3-2*x),expo:x=>x>=1?1:1-Math.pow(2,-10*x),step:x=>Math.floor(x*4)/4,hold:x=>x<1?0:1,in:x=>x*x,out:x=>1-(1-x)*(1-x),inout:x=>x<.5?2*x*x:1-Math.pow(-2*x+2,2)/2,
 bounce:x=>{const n=7.5625,d=2.75;if(x<1/d)return n*x*x;if(x<2/d)return n*(x-=1.5/d)*x+.75;if(x<2.5/d)return n*(x-=2.25/d)*x+.9375;return n*(x-=2.625/d)*x+.984375},
 elastic:x=>x<=0?0:x>=1?1:Math.pow(2,-10*x)*Math.sin((x*10-.75)*2.0944)+1,
 back:x=>1+2.7*Math.pow(x-1,3)+1.7*Math.pow(x-1,2)};
const EASES=[['linear','Linear'],['in','Ease in'],['out','Ease out'],['inout','Ease in-out'],['bounce','Bounce'],['elastic','Elastic'],['back','Back'],['scurve','S-curve'],['expo','Expo out'],['step','Stepped'],['hold','Hold'],['bezier','Bezier']];

/* ---------- keyframes: {p:0..1 along the clip, x/y:% of frame, s:% scale, r:deg, e:ease INTO this key} ---------- */
const KFP=[['x','Position X','%',-100,100],['y','Position Y','%',-100,100],['s','Scale','%',20,300],['r','Rotation','°',-360,360]];
const KF0=()=>[{p:0,x:0,y:0,s:100,r:0,e:'inout'},{p:1,x:0,y:0,s:130,r:0,e:'inout'}];
function kfEval(kf,p){
  const k=kf.slice().sort((a,b)=>a.p-b.p);let a=k[0],b=k[k.length-1];
  if(p>=b.p)a=b;else if(p<=a.p)b=a;else for(let i=0;i<k.length-1;i++)if(p>=k[i].p&&p<=k[i+1].p){a=k[i];b=k[i+1];break}
  const u=b.p>a.p?EASE[b.e||'inout']((p-a.p)/(b.p-a.p)):1,L=q=>a[q]+(b[q]-a[q])*u;
  return{x:L('x'),y:L('y'),s:L('s'),r:L('r')};
}
const BL=['normal','screen','multiply','overlay','soft-light','lighten','difference','hard-light','color-dodge'];let LB=1,LO=.8;
/* ---------- time remap: timeline time -> source time (freeze holds a frame, speed ramps slow it down) ---------- */
function lost(e,t){const p=Math.min(1,Math.max(0,(t-e.t)/e.d));
  if(e.type==='rev')return 2*p*e.d-e.d;
  if(e.type==='loop'){const L=e.d/3,x=p*e.d;return p>=1?e.d:L*Math.floor(x/L)}
  if(e.type==='freeze')return p*e.d;
  if(e.type==='fast')return-(e.amt==null?70:e.amt)/100*2*e.d/Math.PI*(1-Math.cos(Math.PI*p));
  if(e.type==='speed')return(e.amt==null?70:e.amt)/100*.85*e.d/Math.PI*(1-Math.cos(Math.PI*p));
  return 0}
function srcT(t){let s=t;for(const e of state.events)if(e.track==='fx'&&(e.type==='freeze'||e.type==='speed'||e.type==='fast'||e.type==='loop'||e.type==='rev')&&t>e.t)s-=lost(e,t);return Math.max(0,s)}
function vSync(){const v=P.v;if(!v)return;const t=Math.min(srcT(P.t),(v.duration||1e9)-.05),r=(srcT(P.t+.03)-srcT(P.t))/.03;
  if(r<.06){if(!v.paused)v.pause();if(Math.abs(v.currentTime-t)>.03)v.currentTime=t}
  else{v.playbackRate=Math.min(4,r);if(v.paused&&P.playing)v.play();if(Math.abs(v.currentTime-t)>.2)v.currentTime=t}}
function maskMode(on){const s=$('#mdraw');s.style.display=on?'block':'none';MD=on?[]:null;$('#mdl').setAttribute('points','');if(on)toast('Draw around the area to keep')}
function mdPt(e){const r=$('#mdraw').getBoundingClientRect();return[+Math.min(1,Math.max(0,(e.clientX-r.left)/r.width)).toFixed(3),+Math.min(1,Math.max(0,(e.clientY-r.top)/r.height)).toFixed(3)]}
/* ---------- kaleidoscope and 3D cube (canvas) ---------- */
const kalN=e=>2*Math.round(2+(e.amt==null?70:e.amt)/100*3);
function kalDraw(g,src,sw,sh,W,H,n,rot){if(!sw)return;g.save();g.fillStyle='#000';g.fillRect(0,0,W,H);g.translate(W/2,H/2);
  const R=Math.hypot(W,H)/2,a=Math.PI*2/n,s=Math.max(W/sw,H/sh);
  for(let i=0;i<n;i++){g.save();g.rotate(i*a+(i%2?a:0));if(i%2)g.scale(1,-1);g.beginPath();g.moveTo(0,0);g.arc(0,0,R,0,a);g.closePath();g.clip();
    g.rotate(rot);g.drawImage(src,-sw*s/2,-sh*s/2,sw*s,sh*s);g.restore()}
  g.restore()}
let CB=null;
function cubeInit(){const st=$('#stage'),w=st.clientWidth,h=st.clientHeight,box=$('#cube3d');box.innerHTML='<div class="cb"></div>';const cb=box.firstChild;CB={w,cb,cs:[]};
  [[w,h,`translateZ(${w/2}px)`],[w,h,`rotateY(180deg) translateZ(${w/2}px)`],[w,h,`rotateY(90deg) translateZ(${w/2}px)`],[w,h,`rotateY(-90deg) translateZ(${w/2}px)`],[w,w,`rotateX(90deg) translateZ(${h/2}px)`],[w,w,`rotateX(-90deg) translateZ(${h/2}px)`]].forEach(([fw,fh,t])=>{
    const c=document.createElement('canvas');c.width=Math.round(fw/2);c.height=Math.round(fh/2);
    c.style.cssText=`position:absolute;left:${-fw/2}px;top:${-fh/2}px;width:${fw}px;height:${fh}px;transform:${t};backface-visibility:hidden`;cb.append(c);CB.cs.push(c)})}
function cubeDraw(v,rot,rx){if(!CB)cubeInit();CB.cs.forEach(c=>{const g=c.getContext('2d'),s=Math.max(c.width/v.videoWidth,c.height/v.videoHeight);g.drawImage(v,(c.width-v.videoWidth*s)/2,(c.height-v.videoHeight*s)/2,v.videoWidth*s,v.videoHeight*s)});
  CB.cb.style.transform=`translateZ(${-CB.w/2}px) rotateX(${rx}deg) rotateY(${rot}deg)`}
/* ---------- cube export + mask tracking ---------- */
function cubeDrawC(g,v,W,H,rotDeg,d){const sw=v.videoWidth;if(!sw)return;const sh=v.videoHeight,sc=Math.max(W/sw,H/sh),vw=W/sc,vh=H/sc,ox=(sw-vw)/2,oy=(sh-vh)/2,N=48,th=rotDeg*Math.PI/180;
  g.save();g.fillStyle='#000';g.fillRect(0,0,W,H);
  for(let i=0;i<4;i++){const f=th+i*Math.PI/2,nx=Math.sin(f),nz=Math.cos(f);if(nz<=0)continue;let pr=null;
    for(let k=0;k<=N;k++){const u=k/N-.5,x=nx*W/2+u*W*Math.cos(f),z=nz*W/2-u*W*Math.sin(f)-W/2,s=d/(d-z),X=W/2+x*s;
      if(pr)g.drawImage(v,ox+(pr.u+.5)*vw,oy,vw/N,vh,pr.X,H/2-H/2*pr.s,X-pr.X+1,H*pr.s);pr={u,X,s}}}
  g.restore()}
const tk=(tr,p)=>{if(!tr)return[0,0];let a=tr[0],b=tr[tr.length-1];for(let i=0;i<tr.length-1;i++)if(p>=tr[i][0]&&p<=tr[i+1][0]){a=tr[i];b=tr[i+1];break}
  const u=b[0]>a[0]?(p-a[0])/(b[0]-a[0]):0;return[a[1]+(b[1]-a[1])*u,a[2]+(b[2]-a[2])*u]};
async function trackMask(e){const v=P.v;if(!v||!v.videoWidth||!e.pts){toast('Import a video first');return}pause();const keep=P.t,tw=192,th=Math.round(192*v.videoHeight/v.videoWidth),cv=document.createElement('canvas');cv.width=tw;cv.height=th;
  const g=cv.getContext('2d',{willReadFrequently:true});
  const grab=async t=>{v.currentTime=srcT(t);await Promise.race([new Promise(r=>{v.onseeked=r}),wait(500)]);g.drawImage(v,0,0,tw,th);const d=g.getImageData(0,0,tw,th).data,a=new Float32Array(tw*th);
    for(let i=0;i<a.length;i++)a[i]=d[i*4]*.3+d[i*4+1]*.59+d[i*4+2]*.11;return a};
  const xs=e.pts.map(q=>q[0]),ys=e.pts.map(q=>q[1]),x0=Math.max(0,Math.min(tw-8,Math.floor(Math.min(...xs)*tw))),y0=Math.max(0,Math.min(th-8,Math.floor(Math.min(...ys)*th))),
    bw=Math.min(tw-x0,Math.max(8,Math.ceil(Math.max(...xs)*tw)-x0)),bh=Math.min(th-y0,Math.max(8,Math.ceil(Math.max(...ys)*th)-y0)),n=Math.min(240,Math.max(4,Math.round(e.d*15))),R=14,st=bw*bh>1600?3:2;
  const patch=(a,px,py)=>{const o=[];let m=0;for(let y=0;y<bh;y+=st)for(let x=0;x<bw;x+=st){const q=a[(py+y)*tw+px+x];o.push(q);m+=q}m/=o.length;return o.map(q=>q-m)};
  const cost=(T,a,px,py)=>{let m=0,c=0,k=0;for(let y=0;y<bh;y+=st)for(let x=0;x<bw;x+=st)m+=a[(py+y)*tw+px+x];m/=T.length;
    for(let y=0;y<bh;y+=st)for(let x=0;x<bw;x+=st)c+=Math.abs(T[k++]-(a[(py+y)*tw+px+x]-m));return c/T.length};
  toast('Tracking… keep this screen open');const ref=await grab(e.t),T0=patch(ref,x0,y0);let T=T0,cx=x0,cy=y0,vx=0,vy=0;const raw=[[0,0,0]];
  for(let i=1;i<=n;i++){const fr=await grab(e.t+e.d*i/n),gx=Math.round(cx+vx),gy=Math.round(cy+vy);let best=1e18,bx=gx,by=gy;const grid={};
    for(let dy=-R;dy<=R;dy++)for(let dx=-R;dx<=R;dx++){const px=gx+dx,py=gy+dy;if(px<0||py<0||px+bw>tw||py+bh>th)continue;const s=cost(T,fr,px,py)+.02*Math.hypot(px-gx,py-gy);grid[px+','+py]=s;if(s<best){best=s;bx=px;by=py}}
    // sub-pixel refinement (parabola through neighbours)
    let sx=bx,sy=by;const L=grid[(bx-1)+','+by],Rr=grid[(bx+1)+','+by],U=grid[bx+','+(by-1)],D=grid[bx+','+(by+1)];
    if(L!=null&&Rr!=null&&L+Rr-2*best>1e-6)sx=bx+.5*(L-Rr)/(L+Rr-2*best);if(U!=null&&D!=null&&U+D-2*best>1e-6)sy=by+.5*(U-D)/(U+D-2*best);
    // lost check against the first-frame template: if the match is poor, hold position instead of jumping
    const c0=cost(T0,fr,bx,by);if(best>24&&c0>Math.max(18,best*3)){sx=cx+vx*.5;sy=cy+vy*.5;vx*=.5;vy*=.5}
    else{vx=.6*vx+.4*(sx-cx);vy=.6*vy+.4*(sy-cy);const P2=patch(fr,bx,by);T=T.map((q,k)=>.9*q+.1*P2[k])}
    cx=Math.min(tw-bw,Math.max(0,sx));cy=Math.min(th-bh,Math.max(0,sy));raw.push([i/n,(cx-x0)/tw,(cy-y0)/th])}
  // light smoothing of the path
  e.trk=raw.map((r,i)=>{const a=raw[Math.max(0,i-1)],b=raw[Math.min(raw.length-1,i+1)];return[r[0],+((a[1]+2*r[1]+b[1])/4).toFixed(5),+((a[2]+2*r[2]+b[2])/4).toFixed(5)]});
  seek(keep);renderAll();toast('Mask now follows the subject')}
const kfCss=k=>`translate(${k.x}%,${k.y}%) rotate(${k.r}deg) scale(${k.s/100})`;
function lyrBar(){$('#lyrbar').innerHTML=LY?`<button data-ly="mode">${BL[LB]}</button><button data-ly="op">${Math.round(LO*100)}%</button><button data-ly="x">✕</button><button data-ly="mask">Mask</button>`:'<button data-ly="add">+ Layer</button><button data-ly="mask">Mask</button>'}
function lyrApply(){if(LY){LY.style.mixBlendMode=BL[LB];LY.style.opacity=LO}}
function lyrSync(soft){if(!LY)return;const t=Math.max(0,Math.min(P.t,(LY.duration||P.t)-.05));if(!soft||Math.abs(LY.currentTime-t)>.3)LY.currentTime=t}
const kfMarks=e=>(e.kf||[]).map(k=>`<i class="kfd" style="left:${k.p*100}%"></i>`).join('');

/* ---------- effects engine ----------
   [name, category, shape, description, fn(v,{p,T,pv}) -> {t:transform, f:filter, o:{overlay:amount}}, defaultEase]
   shape: pulse (0>1>0) | in (0>1) | out (1>0) | hold (on for the duration) */
const S={};
const UF=(id,x)=>v=>v<.03?{}:{f:'url(#'+id+')'+(x||'')};
const FX={
 zoom:['Punch zoom','Camera','pulse','Quick scale pop',v=>({t:`scale(${1+.3*v})`})],
 push:['Slow push','Camera','in','Gradual push-in',v=>({t:`scale(${1+.25*v})`})],
 shake:['Impact shake','Camera','hold','Camera hit',(v,c)=>({t:`translate(${J(c.T,95)*16*v}px,${J(c.T,71)*12*v}px) rotate(${J(c.T,53)*2*v}deg) scale(${1+.1*v})`})],
 spin:['Spin','Camera','in','Full rotation',v=>({t:`rotate(${360*v}deg) scale(1.25)`})],
 pan:['Pan','Camera','in','Slide across frame',v=>({t:`translateX(${(.5-v)*16}%) scale(1.3)`})],
 drift:['Camera drift','Camera','hold','Slow floating drift',(v,c)=>({t:`translate(${Math.sin(c.T*.7)*3*v}%,${Math.cos(c.T*.5)*2*v}%) scale(${1+.08*v})`})],
 swing:['Swing','Camera','hold','Pendulum sway',(v,c)=>({t:`rotate(${Math.sin(c.T*3)*6*v}deg) scale(1.12)`})],
 orbit:['Orbit','Camera','hold','Circular camera path',(v,c)=>({t:`translate(${Math.cos(c.T*2)*6*v}%,${Math.sin(c.T*2)*6*v}%) scale(1.15)`})],
 roll:['Camera roll','Camera','in','Roll into frame',v=>({t:`rotate(${-25*(1-v)}deg) scale(${1.2-.2*v})`})],
 flip:['3D flip','Camera','pulse','Card flip',v=>({t:`perspective(700px) rotateY(${180*v}deg)`})],
 ramp:['Velocity ramp','Camera','pulse','Speed-ramp feel (look only)',v=>({t:`scale(${1+.35*v})`,f:`blur(${6*v}px) saturate(${1+.5*v})`})],
 squeeze:['Squeeze','Distort','pulse','Squash and stretch',v=>({t:`scale(${1+.25*v},${1-.2*v})`})],
 twist:['Twist','Distort','pulse','Skew twist',v=>({t:`rotate(${12*v}deg) skew(${10*v}deg,${-6*v}deg) scale(1.15)`})],
 contrast:['Contrast','Color','hold','Punchier contrast',v=>({f:`contrast(${1+.6*v})`})],
 warm:['Warm tone','Color','hold','Golden temperature',v=>({f:`sepia(${.35*v}) saturate(${1+.3*v})`})],
 cool:['Cool tone','Color','hold','Blue-teal temperature',v=>({f:`hue-rotate(${-25*v}deg) saturate(${1+.2*v})`})],
 dream:['Dreamy soft','Blur','hold','Soft focus with glow',v=>({f:`blur(${2.5*v}px) brightness(${1+.12*v}) saturate(${1+.2*v})`,o:{glow:v*.7}})],
 neon:['Neon pop','Light','hold','Vivid glowing colour',v=>({f:`saturate(${1+2*v}) contrast(${1+.2*v}) brightness(${1+.1*v})`,o:{glow:v}})],
 pixel:['Pixelate','Distort','pulse','Chunky mosaic blocks',(v,c)=>{if(v<.03)return{};if(c.pv||!S.pxM)return{f:`blur(${4*v}px) contrast(1.3)`};const r=Math.max(1,Math.round(14*v));S.pxF.setAttribute('x',r);S.pxF.setAttribute('y',r);S.pxC.setAttribute('width',2*r+1);S.pxC.setAttribute('height',2*r+1);S.pxM.setAttribute('radius',r);return{f:'url(#f-px)'}}],
 bmul:['Blend: Multiply','Light','hold','Warm-violet multiply tint',v=>({o:{mul:v}})],
 bscr:['Blend: Screen','Light','hold','Dreamy screen glow',v=>({o:{scr:v}})],
 bovl:['Blend: Overlay','Light','hold','Teal-orange overlay grade',v=>({o:{ovl:v}})],
 bsft:['Blend: Soft light','Light','hold','Pastel soft-light wash',v=>({o:{sft:v}})],
 bdod:['Blend: Color dodge','Light','hold','Hot highlight dodge',v=>({o:{dod:v}})],
 bdif:['Blend: Difference','Glitch','hold','Inverted-colour difference',v=>({o:{dif:v}})],
 rcircle:['Circle reveal','Transition','in','Expanding circle reveal',v=>({c:`circle(${Math.min(1,v/.7)*75}% at 50% 50%)`})],
 rwipe:['Wipe reveal','Transition','in','Left-to-right wipe',v=>({c:`inset(0 ${(1-Math.min(1,v/.7))*100}% 0 0)`})],
 rsplit:['Split reveal','Transition','in','Opens from the centre',v=>{const u=Math.min(1,v/.7);return{c:`inset(0 ${50*(1-u)}% 0 ${50*(1-u)}%)`}}],
 rrect:['Rectangle reveal','Transition','in','Box grows to full frame',v=>{const u=Math.min(1,v/.7),k=35*(1-u);return{c:`inset(${k}% round ${20*(1-u)}px)`}}],
 rline:['Line reveal','Transition','in','Thin line opens to full frame',v=>{const u=Math.min(1,v/.7);return{c:`inset(${49*(1-u)}% 0)`}}],
 halftone:['Halftone dots','Distort','hold','Comic dot-screen look',v=>({f:`contrast(${1+.5*v}) saturate(${1-.4*v})`,o:{dots:v}})],
 tilt3d:['3D tilt','Camera','hold','Perspective box tilt',(v,c)=>({t:`perspective(800px) rotateY(${Math.sin(c.T*1.5)*28*v}deg) rotateX(${Math.cos(c.T)*10*v}deg) scale(.9)`})],
 cube:['Cube turn','Transition','pulse','Turn like a cube face',v=>({t:`perspective(900px) translateZ(${-200*v}px) rotateY(${90*v}deg)`})],
 fast:['Speed up','Camera','pulse','Fast-forward burst',v=>({f:`blur(${3*v}px)`})],
 mask:['Free-draw mask','Transition','hold','Show only the area you drew',(v,c)=>{const e=c.e;if(!e||!e.pts)return{};const[dx,dy]=tk(e.trk,c.p);return{c:`polygon(${e.pts.map(q=>(q[0]+dx)*100+'% '+(q[1]+dy)*100+'%').join(',')})`}}],
 kal:['Kaleidoscope','Distort','hold','Mirrored wedges that slowly spin',()=>({})],
 box3d:['3D cube','Camera','hold','Video wrapped on a spinning cube',()=>({})],
 freeze:['Freeze frame','Camera','hold','Hold one frame, then continue',()=>({})],
 speed:['Speed ramp','Camera','pulse','Slow-motion dip (real time remap)',v=>({f:`saturate(${1+.3*v})`})],
 echo:['Echo','Distort','hold','Ghost trail of the clip',()=>({})],
 stutter:['Stutter','Distort','hold','Choppy frame jumps',(v,c)=>({t:`translate(${(Math.floor(c.T*12)%2)*2*v}%,${(Math.floor(c.T*7)%2)*-1.5*v}%)`})],
 pulse:['Glow pulse','Light','hold','Beat-style light pulse',(v,c)=>{const a=Math.abs(Math.sin(c.T*6));return{f:`brightness(${1+.35*v*a})`,o:{glow:v*.5*a}}}],
 blink:['Blink','Light','hold','Fast opacity blink',(v,c)=>({f:`opacity(${1-.9*v*(Math.floor(c.T*8)%2)})`})],
 ghost:['Ghost','Light','hold','See-through fade',v=>({f:`opacity(${1-.6*v})`})],
 rgbf:['RGB flash','Transition','pulse','Colour-split white flash',v=>({f:`hue-rotate(${120*v}deg) saturate(${1+v})`,o:{flash:v*.7}})],
 bxf:['Blur crossfade','Transition','pulse','Soft blur through the cut',v=>({f:`blur(${14*v}px)`,o:{black:v*.25}})],
 push2:['Push slide','Transition','pulse','Slide push at the cut',(v,c)=>({t:`translateX(${(c.p-.5)*-40}%)`,f:`blur(${5*v}px)`})],
 motion:['Keyframe motion','Camera','kf','Animate position, scale and rotation over time',()=>({})],
 pop:['Pop','Camera','in','Bouncy scale in',v=>({t:`scale(${.7+.3*v})`}),'bounce'],
 blur:['Gaussian blur','Blur','pulse','Soft focus blur',v=>({f:`blur(${12*v}px)`})],
 mblur:['Motion blur','Blur','pulse','Directional streak',(v,c)=>{if(c.pv||!S.mbs)return{f:`blur(${6*v}px)`};S.mbs.setAttribute('stdDeviation',`${28*v} 0`);return{f:'url(#f-mb)'}}],
 rblur:['Zoom blur','Blur','pulse','Radial zoom burst',v=>({t:`scale(${1+.18*v})`,f:`blur(${5*v}px)`})],
 bcon:['Brightness / Contrast','Color','hold','Lift light and punch',v=>({f:`brightness(${1+.2*v}) contrast(${1+.35*v})`})],
 gamma:['Gamma','Color','hold','Lift the midtones',v=>({f:`brightness(${1+.3*v}) contrast(${1-.18*v})`})],
 sat:['Saturation','Color','hold','Push colour strength',v=>({f:`saturate(${1+2*v})`})],
 vibr:['Vibrance','Color','hold','Gentle colour boost',v=>({f:`saturate(${1+.7*v}) contrast(${1+.08*v})`})],
 tint:['Tint','Color','hold','Shift towards magenta/green',v=>({f:`hue-rotate(${35*v}deg) saturate(${1+.15*v})`})],
 color:['Colorize','Color','hold','Wash the shot in one colour',v=>({f:`grayscale(${v*.6}) sepia(${v}) hue-rotate(${150*v}deg) saturate(${1+2*v})`})],
 thresh:['Threshold','Color','hold','Hard black and white',v=>({f:`grayscale(1) contrast(${1+9*v}) brightness(${1+.2*v})`})],
 shad:['Shadows','Color','hold','Open up dark areas',v=>({f:`brightness(${1+.3*v}) contrast(${1-.25*v})`})],
 highl:['Highlights','Color','hold','Pull down bright areas',v=>({f:`brightness(${1-.2*v}) contrast(${1+.2*v})`})],
 levels:['Levels','Color','hold','Deeper blacks, cleaner whites',v=>({f:`contrast(${1+.5*v}) brightness(${1-.08*v})`})],
 cbal:['Color balance','Color','hold','Teal and warm split look',v=>({f:`sepia(${.25*v}) hue-rotate(${-15*v}deg) saturate(${1+.4*v})`})],
 gmap:['Gradient map','Color','hold','Map light and dark to two colours',v=>({f:`grayscale(1) sepia(${v}) hue-rotate(${170*v}deg) saturate(${1+2.5*v}) contrast(${1+.2*v})`})],
 sharp:['Sharpen','Blur','hold','Crisper detail',v=>({f:`contrast(${1+.3*v}) saturate(${1+.1*v})`})],
 lensb:['Lens blur','Blur','pulse','Soft blur with a lift',v=>({f:`blur(${7*v}px) brightness(${1+.1*v})`,t:`scale(${1+.04*v})`})],
 zout:['Zoom out','Camera','in','Pull back from a close shot',v=>({t:`scale(${1.35-.35*v})`})],
 dolly:['Dolly zoom','Camera','pulse','Push in with a stretching feel',v=>({t:`scale(${1+.3*v}) perspective(500px) rotateX(${6*v}deg)`})],
 flipx:['Flip horizontal','Camera','pulse','Turn the shot like a card',v=>({t:`scaleX(${Math.cos(Math.PI*v)})`})],
 fin:['Fade in','Color','out','Rise from black',v=>({f:`brightness(${1-v})`})],
 swirl:['Swirl','Distort','hold','Swaying twist',(v,c)=>({t:`rotate(${Math.sin(c.T*4)*9*v}deg) scale(${1.1+.05*v})`,f:`blur(${1.5*v}px)`})],
 irid:['Iridescence','Light','hold','Shifting rainbow sheen',(v,c)=>({f:`hue-rotate(${Math.sin(c.T*2)*70*v}deg) saturate(${1+.7*v})`})],
 stripes:['Stripes','Pattern','hold','Bars over the picture',v=>({o:{stripes:v}})],
 check:['Checkerboard','Pattern','hold','Chess-board squares',v=>({o:{check:v}})],
 tiles:['Tiles','Pattern','hold','Grid lines like tile joints',v=>({o:{tiles:v}})],
 clouds:['Clouds','Pattern','hold','Soft cloud haze',v=>({o:{clouds:v}})],
 stars:['Starfield','Pattern','hold','Scattered stars',v=>({o:{stars:v}})],
 rays:['Light rays','Light','hold','Beams from the top',v=>({o:{rays:v}})],
 glint:['Glint','Light','pulse','A sparkle and light sweep',v=>({o:{glint:v}})],
 badd:['Add','Light','hold','Adds light (linear dodge)',v=>({o:{badd:v}})],
 bdar:['Darken','Light','hold','Keeps the darker of picture and colour',v=>({o:{bdar:v}})],
 blit:['Lighten','Light','hold','Keeps the lighter of picture and colour',v=>({o:{blit:v}})],
 bhrd:['Hard light','Light','hold','Strong contrasty colour layer',v=>({o:{bhrd:v}})],
 bexc:['Exclusion','Light','hold','Soft inverted colour mix',v=>({o:{bexc:v}})],
 repl:['Replace color','Color','hold','Rotates the colours of the picture',v=>({f:`hue-rotate(${120*v}deg) saturate(${1+.5*v})`})],
 chmap:['Channel map','Color','hold','Swaps red and blue',UF('f-chmap')],
 edge:['Find edges','Edges','hold','Bright outlines on black',UF('f-edge')],
 sketch:['Sketch','Edges','hold','Pencil lines on white',UF('f-sketch')],
 lineart:['Line art','Edges','hold','Hard black ink lines',UF('f-line')],
 outline:['Outline','Edges','hold','Gold outlines over a dim picture',UF('f-outline')],
 neonout:['Neon outline','Edges','hold','Glowing cyan outlines',UF('f-neon')],
 stroke:['Stroke','Edges','hold','Thick outlines',UF('f-stroke')],
 astroke:['Animated stroke','Edges','hold','Neon outline with cycling colour',(v,c)=>v<.03?{}:{f:`url(#f-neon) hue-rotate(${(c.T*90)%360}deg)`}],
 contour:['Contour','Edges','hold','Posterised bands with lines',UF('f-cont')],
 rough:['Roughen edges','Edges','hold','Jittery hand-cut edges',UF('f-rough')],
 drawp:['Drawing progress','Edges','hold','Sketch lines draw in left to right',(v,c)=>v<.03?{}:{f:'url(#f-sketch)',c:`inset(0 ${(1-c.p)*100}% 0 0)`}],
 ckey:['Chroma key','Key','hold','Removes green',UF('f-ckey')],
 lkey:['Luma key','Key','hold','Removes dark areas',UF('f-lkey')],
 choke:['Matte choker','Key','hold','Green key with shrunk soft edge',UF('f-choke')],
 alpha:['Alpha','Key','hold','Make the picture see-through',v=>({f:`opacity(${1-.85*v})`})],
 opac:['Opacity','Key','pulse','Dip the picture opacity',v=>({f:`opacity(${1-.9*v})`})],
 cyl:['Cylinder','Camera','hold','Wraps the picture round a drum',(v,c)=>v<.03?{}:{f:'url(#f-cyl)',t:'scale(1.06)'}],
 sph:['Sphere','Camera','hold','Pillow-bulge fisheye',(v,c)=>v<.03?{}:{f:'url(#f-sph)',t:'scale(1.08)'}],
 shadow:['Shadow','Camera','hold','Floating picture with soft shadow',v=>({f:`drop-shadow(0 ${14*v}px ${24*v}px rgba(0,0,0,.75))`,t:`scale(${1-.14*v})`})],
 lshadow:['Long shadow','Camera','hold','Hard diagonal shadow',v=>({f:`drop-shadow(${26*v}px ${26*v}px 0 rgba(0,0,0,.65))`,t:`scale(${1-.18*v})`})],
 page:['Page turn','Transition','pulse','Turn like a page',v=>({t:`translateX(-50%) perspective(900px) rotateY(${-110*v}deg) translateX(50%)`})],
 morph:['Morph','Distort','pulse','Liquid stretch and squash',(v,c)=>({t:`skewX(${Math.sin(c.T*5)*8*v}deg) scale(${1+.1*v},${1-.06*v})`,f:`blur(${3*v}px) saturate(${1+.4*v})`})],
 loop:['Loop','Camera','hold','Repeats the start of the clip 3 times (real time remap)',()=>({})],
 rev:['Reverse motion','Camera','hold','Plays the section backwards, then forwards (real time remap)',()=>({})],
 bw:['Black & white','Color','hold','Remove colour',v=>({f:`grayscale(${v})`})],
 sepia:['Sepia','Color','hold','Warm vintage tone',v=>({f:`sepia(${v})`})],
 invert:['Invert','Color','pulse','Negative colours',v=>({f:`invert(${v})`})],
 hue:['Hue shift','Color','in','Cycle the colours',v=>({f:`hue-rotate(${360*v}deg)`})],
 vivid:['Vivid','Color','hold','Boost colour and contrast',v=>({f:`saturate(${1+1.5*v}) contrast(${1+.25*v})`})],
 exposure:['Exposure','Color','pulse','Brighten the shot',v=>({f:`brightness(${1+.9*v})`})],
 fade:['Fade out','Color','in','Dim to black',v=>({f:`brightness(${1-v})`})],
 vig:['Vignette','Color','hold','Dark cinematic edges',v=>({o:{vig:v}})],
 glow:['Soft glow','Light','pulse','Golden bloom',v=>({f:`brightness(${1+.15*v}) saturate(${1+.35*v})`,o:{glow:v}})],
 flash:['Flash','Light','pulse','White flash',v=>({o:{flash:v}})],
 strobe:['Strobe','Light','hold','Rapid flashing',(v,c)=>({o:{flash:(Math.floor(c.T*14)%2)*v}})],
 flicker:['Flicker','Light','hold','Random brightness',(v,c)=>({f:`brightness(${1-.5*v*Math.abs(J(c.T,60))})`})],
 leak:['Light leak','Light','pulse','Warm film leak',v=>({o:{leak:v}})],
 rgb:['RGB split','Glitch','pulse','Chromatic aberration',(v,c)=>{if(c.pv||!S.rR)return{f:`saturate(${1+v}) contrast(1.15)`};S.rR.setAttribute('dx',12*v);S.rB.setAttribute('dx',-12*v);return{f:'url(#f-rgb)'}}],
 glitch:['Glitch','Glitch','hold','Jitter and colour tear',(v,c)=>({t:`translate(${J(c.T,120)*10*v}px,0) skewX(${J(c.T,90)*6*v}deg)`,f:`hue-rotate(${J(c.T,40)*60*v}deg) contrast(${1+.3*v})`,o:{scan:v*.5}})],
 vhs:['VHS','Glitch','hold','Tape wobble and noise',(v,c)=>({t:`translateY(${J(c.T,30)*3*v}px)`,f:`saturate(${1+.4*v}) blur(${.6*v}px) hue-rotate(${-10*v}deg)`,o:{scan:v*.8,grain:v*.5}})],
 scan:['Scanlines','Glitch','hold','CRT lines',v=>({o:{scan:v}})],
 grain:['Film grain','Glitch','hold','Analog noise',v=>({o:{grain:v*.8}})],
 wave:['Wave','Distort','hold','Liquid ripple',(v,c)=>{if(c.pv||!S.wd)return{t:`skewX(${Math.sin(c.T*8)*6*v}deg)`};S.wd.setAttribute('scale',40*v);S.wt.setAttribute('baseFrequency',`.008 ${.02+.01*Math.sin(c.T*3)}`);return{f:'url(#f-wave)'}}],
 tilt:['Tilt','Distort','pulse','Dutch angle',v=>({t:`rotate(${9*v}deg) scale(1.15)`})],
 mirror:['Mirror','Distort','hold','Flip horizontally',v=>({t:v>.01?'scaleX(-1)':''})],
 dip:['Dip to black','Transition','pulse','Cut through black',v=>({o:{black:v}})],
 cross:['Dissolve','Transition','pulse','Soft dissolve',v=>({o:{black:v*.45}})],
 whip:['Whip pan','Transition','pulse','Fast sideways swipe',(v,c)=>({t:`translateX(${(c.p-.5)*-70}%) scale(1.2)`,f:`blur(${10*v}px)`})],
 zthru:['Zoom through','Transition','pulse','Punch through the cut',v=>({t:`scale(${1+v})`,f:`blur(${6*v}px)`,o:{flash:v*.5}})],
 spinw:['Spin wipe','Transition','pulse','Twist across the cut',(v,c)=>({t:`rotate(${(c.p-.5)*120}deg) scale(${1+.5*v})`,f:`blur(${4*v}px)`})],
 glcut:['Glitch cut','Transition','pulse','Digital tear at the cut',(v,c)=>({t:`translate(${J(c.T,150)*20*v}px,0)`,f:`hue-rotate(${90*v}deg) contrast(${1+.5*v})`,o:{flash:v*.3,scan:v}})]
};
const KFR=(a,b,e)=>[{p:0,x:0,y:0,s:100,r:0,e:'inout',...a},{p:1,x:0,y:0,s:100,r:0,e:e||'inout',...b}];
/* [name, kind, level, tags, description, stack]; stack item = [effect, duration, amount, start offset, keyframes] */
const PRESETS=[
['Smooth zoom in','Preset','Beginner','#zoom #photomotion #cinematic','Slow push-in with ease in-out',[['motion',3,0,0,KFR({},{s:125})]]],
['Smooth zoom out','Preset','Beginner','#zoom #cinematic','Slow pull-back from a tight frame',[['motion',3,0,0,KFR({s:125},{})]]],
['Zoom punch','Preset','Beginner','#zoom #impact #beatsync','Quick pop on the beat',[['zoom',.4,85]]],
['Soft shake','Preset','Beginner','#shake','Light handheld shake',[['shake',.6,30]]],
['Heavy shake','Preset','Intermediate','#shake #impact','Hard camera hit',[['shake',.6,100]]],
['Camera drift','Preset','Beginner','#photomotion #dreamy','Slow floating move',[['drift',4,80]]],
['Rotation in','Preset','Beginner','#loop #transition','Rotate and settle into frame',[['motion',.8,0,0,KFR({r:-90,s:130},{},'out')]]],
['Bounce scale','Preset','Beginner','#impact #lyrics','Scale up with a bounce',[['motion',.7,0,0,KFR({s:50},{},'bounce')]]],
['Elastic scale','Preset','Intermediate','#impact','Springy scale-in',[['motion',.9,0,0,KFR({s:40},{},'elastic')]]],
['Smooth slide','Preset','Beginner','#transition #minimal','Slide in from the left',[['motion',.8,0,0,KFR({x:-100},{},'out')]]],
['Overshoot move','Preset','Intermediate','#impact','Slide in, overshoot, settle',[['motion',.8,0,0,KFR({x:-80},{},'back')]]],
['Flash','Preset','Beginner','#beatsync #impact','White flash and recover',[['flash',.4,90]]],
['RGB flash','Preset','Beginner','#glitch #transition','Colour-split flash',[['rgbf',.5,80]]],
['Glitch hit','Preset','Intermediate','#glitch','Jitter with RGB split',[['glitch',.6,80],['rgb',.6,70]]],
['Glow pulse','Preset','Beginner','#glow #beatsync','Pulsing light',[['pulse',3,70]]],
['Whip transition','Preset','Beginner','#transition','Fast sideways whip at a cut',[['whip',.5,80]]],
['Spin transition','Preset','Intermediate','#transition','Twist across the cut',[['spinw',.6,80]]],
['Velocity ramp','Preset','Advanced','#velocity #anime','Speed-ramp look (real time remap needs the native render)',[['ramp',.8,80]]],
['Circle reveal','Preset','Beginner','#mask #transition','Expanding circle reveal',[['rcircle',.9,80]]],
['Split reveal','Preset','Beginner','#mask #transition','Opens from the centre',[['rsplit',.8,80]]],
['Teal & orange','Recipe','Intermediate','#cinematic #colorgrading','Overlay grade with extra contrast',[['bovl',4,55],['contrast',4,35]]],
['Light leak dream','Recipe','Beginner','#dreamy #glow','Screen glow with a soft-light wash',[['bscr',4,45],['bsft',4,40],['dream',4,35]]],
['Kaleidoscope trip','Preset','Intermediate','#glitch #dreamy #3d','Mirrored wedges that spin',[['kal',3,70]]],
['Cube spin','Preset','Advanced','#3d #transition','Your video on a spinning cube',[['box3d',3,70]]],
['Speed up burst','Preset','Intermediate','#velocity #beatsync','Fast-forward burst',[['fast',1.2,70]]],
['Freeze impact','Preset','Intermediate','#impact #beatsync','Hold a frame with a flash',[['freeze',.6,100],['flash',.2,60]]],
['Speed ramp dip','Preset','Advanced','#velocity #anime','Slow-motion dip and back',[['speed',1.4,85]]],
['Echo trail','Preset','Beginner','#afterimage #dreamy','Ghost trail behind the clip',[['echo',1.5,70]]],
['Beat impact','Recipe','Intermediate','#beatsync #impact #zoom #shake','Zoom, shake and flash on the hit',[['zoom',.4,80],['shake',.4,55],['flash',.25,50]]],
['Anime velocity','Recipe','Advanced','#anime #velocity','Ramp, shake, RGB split and colour',[['ramp',.8,75],['shake',.5,50],['rgb',.5,60],['vivid',.8,50]]],
['Soft dreamy','Recipe','Beginner','#dreamy #photomotion','Soft focus, glow, slow push',[['dream',4,55],['push',4,40]]],
['Dark cinematic','Recipe','Intermediate','#cinematic #colorgrading','Contrast, vignette, grain, slow push',[['contrast',4,45],['vig',4,70],['grain',4,50],['push',4,35]]],
['VHS tape','Recipe','Beginner','#glitch #vintage','Wobble, scanlines, grain',[['vhs',3,70],['scan',3,40],['grain',3,50]]],
['Neon night','Recipe','Intermediate','#glow #neon','Vivid colour with glow pulse',[['neon',3,60],['pulse',3,50]]],
['Vintage film','Recipe','Beginner','#vintage #colorgrading','Warm tone, grain, vignette',[['warm',4,60],['grain',4,50],['vig',4,50]]]
];
let Q='';const hit=s=>!Q||s.toLowerCase().includes(Q.toLowerCase());
function presetCards(cur){return PRESETS.map((p,i)=>[p,i]).filter(([p])=>(cur==='*'||p[1]+'s'===cur)&&hit(p.slice(0,5).join(' '))).map(([p,i])=>`<div class="fxc" data-pr="${i}"><div class="pv"><div class="pvm"></div><div class="ovp">${OVH}</div></div><b>${p[0]}</b><small>${p[4]}<br><span class="tg">${p[1]} · ${p[2]} · ${p[3]}</span></small><button data-preset="${i}">Add at playhead</button></div>`).join('')||'<p class="sub">No matches.</p>'}
function addPreset(i){const p=PRESETS[i];p[5].forEach(s=>addAt('fx',s[0],FX[s[0]][0],P.t+(s[3]||0),s[1],{amt:s[2]??70,...(s[4]?{kf:s[4].map(k=>({...k}))}:{})}));renderAll();toast(p[0]+' added at '+fmt(P.t))}
const pvEv=c=>c.dataset.pr!=null?PRESETS[c.dataset.pr][5].map(s=>({type:s[0],t:0,d:1,amt:s[2]??70,kf:s[4]})):[{type:c.dataset.fx,t:0,d:1,amt:85}];
const ALIAS={'Zoom In':'push','Snap Zoom':'zoom','Zoom Bounce':'zoom','Zoom Pulse':'zoom','White Flash':'flash','Black Flash':'dip','Beat Flash':'flash','Impact Cut':'zoom','Shake Cut':'shake','Stutter Cut':'stutter','VHS Glitch':'vhs','Lens Flare':'leak','Lens Flare Transition':'leak','Light Sweep':'leak','Shine':'glow','Dark Glow':'glow','Edge Glow':'glow','Oscillate':'wave','Bend':'wave','Stretch':'squeeze','Block Noise':'glitch','TV Damage':'glitch','Digital Distortion':'glitch','Signal Interference':'glitch','Noise':'grain','Dust':'grain','Texture Overlays':'grain','Directional Blur Transition':'mblur','Ripple Transition':'wave','Burning Wipe':'rwipe','Block Dissolve':'pixel','Path Reveal':'rwipe','Liquid Reveal':'rcircle','Mask Blur':'blur','Feather':'blur','Smooth Edges':'blur','Focus Blur':'blur','Background Blur':'blur','Glow Blur':'dream','Color Tune':'contrast','Selective Color':'vivid','Pendulum':'swing','Pendulum Rotation':'swing','Floating':'drift','Smooth Movement':'drift','Slide In':'motion','Path Animation':'motion','Motion Path':'motion','Snap Movement':'motion','Bounce':'motion','Elastic Movement':'motion','Overshoot':'motion','360 Rotation':'spin','Rotation Overshoot':'spin','Camera Tilt':'tilt3d','Perspective Zoom':'tilt3d','360 Viewer':'box3d','Opacity Pulse':'blink','Flash Fade':'flash','Fade Trail':'echo','Tracking Mask':'mask','Tracking':'mask','Shape Mask':'mask','Animated Mask':'mask','Fast Motion':'fast','Halftone Dots':'halftone','Halftone Lines':'halftone','Cube':'box3d','Box':'box3d','Kaleidoscope':'kal','Perspective':'tilt3d','Camera Orbit':'tilt3d','Cube Transition':'cube','Multiply':'bmul','Screen':'bscr','Overlay':'bovl','Soft Light':'bsft','Color Dodge':'bdod','Difference':'bdif','Circle Reveal':'rcircle','Circular Reveal':'rcircle','Mask Reveal':'rcircle','Rectangle Reveal':'rrect','Shape Wipe':'rwipe','Wipe':'rwipe','Line Reveal':'rline','Split Reveal':'rsplit','Pixelate':'pixel','Mosaic':'pixel','Pixel Dissolve':'pixel','Gaussian Blur':'blur','Directional Blur':'mblur','Motion Blur':'mblur','Radial Blur':'rblur','Zoom Blur':'rblur','Glitch':'glitch','Flash':'flash','Glow':'glow','Bloom':'glow','Neon Glow':'neon','Sepia':'sepia','Invert':'invert','Hue Shift':'hue','Monochrome':'bw','RGB Split':'rgb','RGB Offset':'rgb','Chromatic Aberration':'rgb','Scanlines':'scan','Film Grain':'grain','Grain':'grain','Mirror':'mirror','Wave Warp':'wave','Ripple':'wave','Squeeze':'squeeze','Twist':'twist','VHS Distortion':'vhs','Light Leaks':'leak','Exposure':'exposure','Saturation':'vivid','Brightness / Contrast':'contrast','Temperature':'warm','Flicker':'flicker','Blink':'blink','Ghost Effect':'ghost','Stutter':'stutter','Shake':'shake','Camera Shake':'shake','Impact Shake':'shake','Swing':'swing','Orbit':'orbit','Drift':'drift','Camera Drift':'drift','Spin':'spin','Fast Spin':'spin','Zoom Punch':'zoom','Camera Push':'push','Slow Zoom':'push','Smooth Zoom':'push','Zoom Whip':'whip','Whip Pan':'whip','Tilt':'tilt','Card Flip':'flip','3D Rotation':'flip','Flip Horizontal':'mirror','Fade Out':'fade','Pulse Opacity':'blink','Flash Transition':'flash','Dip to Black':'dip','Dissolve':'cross','Zoom Impact':'zthru','Spin Transition':'spinw','Glitch Transition':'glcut','RGB Flash':'rgbf','Blur Crossfade':'bxf','Push Transition':'push2','Speed Ramp':'speed','Freeze Frame':'freeze','Freeze Frame Impact':'freeze','Time Remapping':'speed','Speed Ramping':'speed','Echo':'echo','Afterimage':'echo','Motion Trails':'echo','Vignette':'vig','Strobe':'strobe','Light Pulse':'pulse','Animated Glow':'pulse'};
Object.assign(ALIAS,{'Brightness / Contrast':'bcon','Gamma':'gamma','Saturation':'sat','Vibrance':'vibr','Temperature':'warm','Tint':'tint','Colorize':'color','Threshold':'thresh','Shadows':'shad','Highlights':'highl','Levels':'levels','Color Balance':'cbal','Gradient Map':'gmap','Palette Map':'gmap','Sharpen':'sharp','Lens Blur':'lensb','Box Blur':'blur','Depth Blur':'lensb','Zoom Out':'zout','Camera Pull':'zout','Dolly Zoom':'dolly','Flip Horizontal':'flipx','Fade In':'fin','Fade Out':'fade','Swirl':'swirl','Iridescence':'irid','Turbulence':'wave','Displacement Map':'wave','Lightning':'strobe','Light Pulse':'glow','Animated Glow':'glow','Camera Follow':'drift','Dynamic Framing':'drift','Slow Zoom':'push','Zoom Punch':'zoom','Zoom Impact':'zoom','Camera Push':'push','Fast Spin':'spin','Smooth Slow Motion':'ramp','Speed Ramping':'ramp','Speed Ramp':'ramp','Time Remapping':'ramp','Velocity Editing':'ramp','Freeze Frame Impact':'freeze','Ghost Effect':'ghost','Afterimage':'echo','Motion Trails':'echo','Impact Animation':'shake','Camera Roll':'roll','Camera Shake':'shake','Impact Shake':'shake'});
Object.assign(ALIAS,{'Add':'badd','Darken':'bdar','Lighten':'blit','Hard Light':'bhrd','Exclusion':'bexc','Stripes':'stripes','Checkerboard':'check','Tiles':'tiles','Clouds':'clouds','Starfield':'stars','Contour Lines':'contour','Contour':'contour','Light Rays':'rays','Glint':'glint','Replace Color':'repl','Channel Map':'chmap','Find Edges':'edge','Sketch':'sketch','Line Art':'lineart','Outline':'outline','Neon Outline':'neonout','Stroke':'stroke','Animated Stroke':'astroke','Roughen Edges':'rough','Drawing Progress':'drawp','Chroma Key':'ckey','Luma Key':'lkey','Matte Choker':'choke','Alpha':'alpha','Opacity':'opac','Cylinder':'cyl','Sphere':'sph','Shadow':'shadow','Long Shadow':'lshadow','Page Turn':'page','Morph':'morph','Loop':'loop','Reverse Motion':'rev'});
const TXTMAP={'Typewriter':'type','Text Spacing':'spacing','Text Randomizer':'rand','Count Up':'countup','Count Down':'countdown','Text Scramble':'scramble','Jitter':'jitter','Character Reveal':'char','Word Reveal':'word','Text Glow':'tglow','Text Shadow':'tshadow','Text Bounce':'bounce','Text Fade':'fade','Text Slide':'slide','Text Pop':'pop','Text Wave':'wave','Text Shake':'shake','Text Flicker':'flicker','Kinetic Typography':'kinetic','Animated Captions':'caption'};
const CURVEMAP={'Linear':'linear','Ease In':'in','Ease Out':'out','Ease In-Out':'inout','Elastic':'elastic','Back Ease':'back','S-Curve':'scurve','Stepped':'step','Hold':'hold','Bezier Curve':'bezier'};
const stag=(type,label)=>()=>{[0,.18,.36,.54].forEach(o=>addAt('fx',type,FX[type][0],P.t+o,.3,{amt:55}));renderAll();toast(label+' added at '+fmt(P.t))};
const ACT={
  beatsync(){if(!state.beats||!state.beats.length){toast('Import a video with music first');return}const cl=state.events.filter(e=>e.track==='video').sort((a,b)=>a.t-b.t);let n=0;
    for(let i=1;i<cl.length;i++){const c=cl[i],nb=state.beats.reduce((m,b)=>Math.abs(b-c.t)<Math.abs(m-c.t)?b:m,state.beats[0]),dt=nb-c.t;if(Math.abs(dt)<.5&&Math.abs(dt)>.01&&cl[i-1].d+dt>.3&&c.d-dt>.3){cl[i-1].d+=dt;c.t=nb;c.d-=dt;n++}}
    renderAll();toast(n+' cuts moved onto beats')},
  markbeats(){if(!state.beats||!state.beats.length){toast('Import a video with music first');return}const have=new Set(state.events.filter(e=>e.track==='audio').map(e=>e.t.toFixed(2)));let n=0;state.beats.forEach(t=>{if(!have.has(t.toFixed(2))){addAt('audio','beat','',t,.2);n++}});renderAll();toast(n+' beat markers added')},
  rhythm(){if(!state.beats||state.beats.length<2){toast('Import a video with music first');return}let n=0;state.beats.forEach((t,i)=>{if(i%2===0){addAt('fx','zoom','Punch zoom',t,.35,{amt:45});n++}});renderAll();toast(n+' rhythm zooms added on beats')},
  tltiming(){const cuts=starts();if(!cuts.length){toast('No cuts to time against');return}let n=0;state.events.forEach(e=>{if(e.track==='fx'&&FX[e.type]&&FX[e.type][1]==='Transition'&&e.type!=='mask'){const c=cuts.reduce((m,b)=>Math.abs(b-e.t-e.d/2)<Math.abs(m-e.t-e.d/2)?b:m,cuts[0]);e.t=Math.max(0,c-e.d/2);n++}});renderAll();toast(n+' transitions centred on cuts')},
  stagA:stag('pop','Stagger animation'),stagM:stag('swing','Stagger movement'),stagF:stag('flicker','Staggered fade')};
const ACTN={'Beat Sync':'beatsync','Beat Markers':'markbeats','Visual Rhythm':'rhythm','Transition Timing':'tltiming','Stagger Animation':'stagA','Stagger Movement':'stagM','Staggered Fade':'stagF'};
const SPECIAL=s=>ACTN[s]?`<button class="chip on" data-act="${ACTN[s]}">${s}</button>`:TXTMAP[s]?`<button class="chip on" data-tanim="${TXTMAP[s]}">${s}</button>`:CURVEMAP[s]?`<button class="chip on" data-ease="${CURVEMAP[s]}">${s}</button>`:null;
const GUIDE=[
['Color & grading','Look and mood. Best for every edit style.','Brightness / Contrast,Exposure,Gamma,Color Tune,Saturation,Vibrance,Temperature,Tint,Colorize,Hue Shift,Gradient Map,Palette Map,Replace Color,Threshold,Invert,Monochrome,Sepia,RGB Split,Channel Map,Shadows,Highlights,Levels,Color Balance,Selective Color'],
['Blur & focus','Speed, depth and softness.','Gaussian Blur,Box Blur,Directional Blur,Motion Blur,Lens Blur,Radial Blur,Zoom Blur,Mask Blur,Feather,Smooth Edges,Sharpen,Glow Blur,Focus Blur,Background Blur,Depth Blur'],
['Glow & light','Impact, dream and neon looks.','Glow,Dark Glow,Edge Glow,Light Sweep,Lens Flare,Light Rays,Light Leaks,Lightning,Iridescence,Glint,Shine,Bloom,Flash,Neon Glow,Light Pulse,Animated Glow'],
['Distortion & glitch','Cyber, VHS and energy.','Wave Warp,Displacement Map,Ripple,Swirl,Oscillate,Bend,Squeeze,Stretch,Twist,Turbulence,Block Noise,TV Damage,Scanlines,Glitch,Chromatic Aberration,VHS Distortion,Digital Distortion,RGB Offset,Signal Interference'],
['Patterns & texture','Retro and graphic looks.','Mosaic,Pixelate,Halftone Dots,Stripes,Checkerboard,Tiles,Grid Repeat,Mirror,Kaleidoscope,Contour Lines,Clouds,Noise,Starfield,Grain,Film Grain,Dust,Texture Overlays'],
['3D & depth','Perspective and camera depth.','360 Viewer,Box,Cube,Cylinder,Sphere,Perspective,Long Shadow,Shadow,Reflection,Card Flip,3D Rotation,Camera Orbit,Camera Tilt,Parallax,Perspective Zoom'],
['Blend modes','Layer looks that mix with the picture below.','Multiply,Screen,Overlay,Soft Light,Color Dodge,Difference,Add,Darken,Lighten,Hard Light,Exclusion'],
['Masking & keying','Reveals, cutouts and transparency.','Chroma Key,Luma Key,Matte Choker,Alpha,Opacity,Wipe,Fade Out,Dissolve,Block Dissolve,Burning Wipe,Mask Reveal,Shape Mask,Tracking Mask,Animated Mask'],
['Drawing & edges','Outlines and line animation.','Drawing Progress,Stroke,Find Edges,Edge Glow,Roughen Edges,Contour,Outline,Neon Outline,Sketch,Line Art,Path Reveal'],
['Text','Lyrics, titles and captions.','Typewriter,Text Spacing,Text Randomizer,Count Up,Count Down,Text Scramble,Jitter,Character Reveal,Word Reveal,Text Glow,Text Shadow,Text Bounce,Text Fade,Text Slide,Text Pop,Text Wave,Text Shake,Text Flicker,Kinetic Typography,Animated Captions'],
['Time & layers','Rhythm and trails.','Echo,Time Remapping,Freeze Frame,Frame Blending,Stutter,Flicker,Blink,Pulse Opacity,Ghost Effect,Loop,Afterimage,Reverse Motion,Motion Trails,Speed Ramp'],
['Position & movement','Natural camera and object motion.','Smooth Movement,Slide In,Drift,Floating,Path Animation,Orbit,Pendulum,Swing,Overshoot,Bounce,Elastic Movement,Shake,Camera Shake,Impact Shake,Snap Movement,Stagger Movement'],
['Scale & zoom','Punch, push and pull.','Zoom In,Zoom Out,Slow Zoom,Zoom Punch,Zoom Bounce,Zoom Pulse,Snap Zoom,Dolly Zoom,Camera Push,Camera Pull,Zoom Whip,Zoom Blur,Zoom Impact'],
['Rotation','Spins, tilts and rolls.','Spin,Fast Spin,360 Rotation,Tilt,Swing,Rotation Overshoot,Flip Horizontal,Card Flip,Camera Roll,Pendulum Rotation'],
['Opacity','Fades and flickers.','Fade In,Fade Out,Flash Fade,Flicker,Blink,Opacity Pulse,Ghost Effect,Fade Trail,Staggered Fade,Dissolve'],
['Shape animation','Reveals and morphs.','Morph,Circle Reveal,Rectangle Reveal,Shape Wipe,Line Reveal,Split Reveal,Liquid Reveal,Animated Stroke,Motion Path'],
['Transitions','Cuts that feel intentional.','Smooth Zoom,Zoom Whip,Zoom Blur,Snap Zoom,Zoom Impact,Whip Pan,Push Transition,Directional Blur Transition,Spin Transition,3D Flip,Page Turn,Cube Transition,RGB Flash,White Flash,Black Flash,Dip to Black,Glitch Transition,Pixel Dissolve,Block Dissolve,VHS Glitch,Flash Transition,Light Leak,Lens Flare Transition,Blur Crossfade,Dissolve,Circular Reveal,Ripple Transition,Burning Wipe,Beat Flash,Shake Cut,Stutter Cut,Impact Cut'],
['Curves','Easing makes motion feel natural. Pick one per keyframe.','Linear,Ease In,Ease Out,Ease In-Out,Overshoot,Bounce,Elastic,Back Ease,S-Curve,Stepped,Hold,Bezier Curve,Speed Ramping'],
['Techniques','Editing habits, not effects.','Velocity Editing,Beat Sync,Parallax,Impact Animation,Tracking,Motion Trails,Afterimage,Match Cut,Stagger Animation,Smooth Slow Motion,Freeze Frame Impact,Camera Follow,Dynamic Framing,Visual Rhythm,Beat Markers,Transition Timing']
];
const DESC={'Grid Repeat':'Not built: needs many live copies of the video on a canvas.','Reflection':'Not built: a mirrored floor needs a second draw pass in the export.','Parallax':'Not built: needs depth information per pixel.','Frame Blending':'Not built: needs frame interpolation.','Match Cut':'Not built: needs the AI to find two similar shots.','Replace Color':'Swaps one chosen colour for another.','Levels':'Sets the black, white and midtone points of the picture.','Color Balance':'Tints shadows, midtones and highlights separately.','Light Rays':'Beams of light streaming from a bright point.','Iridescence':'A shifting rainbow sheen like oil on water.','Stripes':'Repeating bars over or through the picture.','Checkerboard':'A chess-board pattern of squares.','Tiles':'The picture repeated in a grid of tiles.','Grid Repeat':'Many small copies of the shot in rows and columns.','Clouds':'Soft cloudy noise, often used as a texture.','Shadow':'A soft shadow behind a layer or text.','Add':'Adds light values together for a bright glow. Blend mode.','Darken':'Keeps the darker pixel of two layers. Blend mode.','Lighten':'Keeps the lighter pixel of two layers. Blend mode.','Hard Light':'Strong contrast blend driven by the top layer. Blend mode.','Exclusion':'A softer, lower-contrast cousin of Difference. Blend mode.','Alpha':'The transparency channel of a layer.','Opacity':'How see-through a layer is. Layers have an opacity control now.','Drawing Progress':'A line that draws itself on over time.','Roughen Edges':'Gives edges a rough, hand-cut look.','Contour':'Lines that follow the shape of the subject.','Outline':'A line around the edge of a shape or subject.','Neon Outline':'A glowing outline.','Sketch':'Turns the picture into a pencil drawing.','Line Art':'Reduces the picture to clean ink lines.','Text Spacing':'Changes the gap between letters.','Text Randomizer':'Letters change randomly before settling.','Count Down':'A number that ticks downward.','Jitter':'Tiny random shakes in position.','Character Reveal':'Letters appear one at a time.','Word Reveal':'Words appear one at a time.','Text Glow':'A soft glow around text.','Text Shadow':'A drop shadow behind text.','Text Bounce':'Letters bounce into place.','Text Fade':'Text fades in or out.','Text Slide':'Text slides into view.','Text Pop':'Text scales up with a pop.','Text Wave':'Letters ripple up and down in a wave.','Text Shake':'Text trembles on the beat.','Text Flicker':'Text blinks like a faulty sign.','Kinetic Typography':'Text that moves and changes with the rhythm of the audio.','Animated Captions':'Subtitles that animate word by word.','Loop':'Repeats an animation over and over.','Stagger Movement':'Items start moving one after another.','Zoom Out':'Pulls the camera back. Use Keyframe motion with scale going down.','Staggered Fade':'Items fade in one after another.','Fade In':'Rises from black to the picture.','Animated Stroke':'An outline that draws itself.','Camera Pull':'Pulls the camera back. Use Keyframe motion with scale going down.','Linear':'Constant speed. Available now as an easing curve.','Ease In':'Starts slow, then speeds up. Available now as an easing curve.','Ease Out':'Starts fast, then slows down. Available now as an easing curve.','Ease In-Out':'Slow start and slow end. Available now as an easing curve.','Elastic':'Springs past the target and wobbles. Available now as an easing curve.','Back Ease':'Pulls back first, then overshoots. Available now as an easing curve.','S-Curve':'A smooth S-shaped speed curve. Available now as an easing curve.','Stepped':'Jumps in steps instead of gliding. Available now as an easing curve.','Hold':'Stays put, then jumps at the end. Available now as an easing curve.','Velocity Editing':'Speed changes timed to the music. Use Speed ramp, Speed up and Freeze frame.','Beat Sync':'Cuts and effects land on the beat. Import a video to find beats automatically.','Impact Animation':'A quick hit of zoom, shake or flash on a strong beat. See the Beat impact recipe.','Stagger Animation':'Several parts animate with small delays between them.','Smooth Slow Motion':'Slow motion that eases in and out. Use Speed ramp.','Camera Follow':'The frame follows a moving subject. Use a tracked mask or Keyframe motion.','Dynamic Framing':'Changing the crop and zoom as the shot goes on.','Visual Rhythm':'Repeating pace and motion that matches the music.','Beat Markers':'Marks on the timeline at each beat. Use the Beat button or import a video.','Transition Timing':'Starting the next shot just before the beat for a smoother cut.','Gamma':'Lifts or darkens the midtones without clipping.','Vibrance':'Boosts muted colours more than already vivid ones.','Tint':'Shifts the picture toward green or magenta.','Colorize':'Paints the whole shot in one colour.','Gradient Map':'Maps dark-to-light tones onto a colour gradient.','Palette Map':'Recolours the picture using a small palette.','Threshold':'Turns the picture into pure black and white.','Channel Map':'Swaps or remaps the red, green and blue channels.','Shadows':'Lifts or crushes only the darkest areas.','Highlights':'Pulls down or boosts only the brightest areas.','Box Blur':'A flat, fast blur with squarer softness.','Lens Blur':'Blur shaped like a camera aperture.','Sharpen':'Adds crispness to edges.','Depth Blur':'Blurs the background, keeps the subject sharp.','Lightning':'Branching electric bolts over the picture.','Glint':'A small sparkle that sweeps across a bright point.','Displacement Map':'Pushes pixels around using another image.','Swirl':'Twists the picture around its centre.','Turbulence':'Organic wobbly distortion.','Kaleidoscope':'Mirrored, rotating wedges.','Contour Lines':'Draws lines along tone levels.','Starfield':'Drifting dots like stars.','Sphere':'Wraps the picture around a ball.','Cylinder':'Wraps the picture around a tube.','Long Shadow':'A hard shadow stretching away from the subject.','Reflection':'A mirrored copy below the picture.','Chroma Key':'Removes a chosen colour, such as green screen.','Luma Key':'Removes the dark or bright parts.','Matte Choker':'Shrinks or grows the edge of a cutout.','Find Edges':'Turns the picture into outlines.','Stroke':'An outline around a shape or text.','Typewriter':'Letters appear one after another.','Text Scramble':'Letters shuffle before settling.','Count Up':'A number that ticks upward.','Time Remapping':'Changes speed over time on a curve.','Reverse Motion':'Plays the clip backwards.','Frame Blending':'Smooths slow motion by mixing frames.','Dolly Zoom':'Zoom in while the background stretches out.','Morph':'One shape flows into another.','Page Turn':'The picture peels away like a page.','Bezier Curve':'A custom curve you shape with handles.','Match Cut':'A cut that links two shots by matching shape or motion.','Parallax':'Layers move at different speeds for depth.'};
function guideHtml(){const K=Object.keys(FX);return GUIDE.map(([t,sub,items])=>{const li=items.split(',').filter(s=>hit(s+' '+t));if(!li.length)return'';
return `<div style="grid-column:1/-1"><b>${t}</b><small class="sub">${sub}</small><div class="gl">${li.map(s=>{const sp=SPECIAL(s);if(sp)return sp;const k=ALIAS[s]||K.find(k=>FX[k][0].toLowerCase()===s.toLowerCase());return k?`<button class="chip on" data-add="${k}">${s}</button>`:`<button class="chip" data-info="${DESC[s]||'Planned. Not in KINO yet.'}">${s}</button>`}).join('')}</div></div>`}).join('')||'<p class="sub">No matches.</p>'}
function save(){try{localStorage.setItem('kino.v1',JSON.stringify({events:state.events,nid:state.nid,dur:P.dur,style:state.style}))}catch(e){}}
function commit(){const j=JSON.stringify(state.events);if(j===H.last)return;const n=Date.now();if(n-H.t>600){H.u.push(H.last);if(H.u.length>80)H.u.shift()}H.t=n;H.last=j;H.r=[];save()}
function hist(from,to){if(!from.length){toast('Nothing to '+(from===H.u?'undo':'redo'));return}to.push(H.last);H.last=from.pop();state.events=JSON.parse(H.last);sel=null;$('#insp').classList.remove('on');H.t=0;renderTL();renderPlan();draw();save()}
function beatsOf(a){
  const sr=a.sampleRate,ch=a.numberOfChannels,len=a.length,h=512,n=Math.floor(len/h);
  const d0=a.getChannelData(0),d1=ch>1?a.getChannelData(1):d0,env=new Float32Array(n);
  let p=0,lp=0;
  for(let i=0;i<n;i++){let s=0;for(let j=0;j<h;j+=2){const k=i*h+j,x=(d0[k]+d1[k])*.5,y=x-lp;lp+=.08*(x-lp);s+=y*y}env[i]=Math.log1p(60*Math.sqrt(s/(h/2)))}
  const f=new Float32Array(n);for(let i=1;i<n;i++)f[i]=Math.max(0,env[i]-env[i-1]);
  const w=Math.round(sr/h*.8),pk=[];
  for(let i=2;i<n-2;i++){const lo=Math.max(0,i-w),hi=Math.min(n,i+w);let m=0,sd=0;for(let k=lo;k<hi;k++)m+=f[k];m/=hi-lo;for(let k=lo;k<hi;k++)sd+=(f[k]-m)**2;sd=Math.sqrt(sd/(hi-lo));
    if(f[i]>m+1.4*sd+.01&&f[i]>=f[i-1]&&f[i]>=f[i+1]&&f[i]>=f[i-2]&&f[i]>=f[i+2])pk.push({t:i*h/sr,v:f[i]})}
  // tempo from autocorrelation of onset strength (60-180 bpm)
  const fr=sr/h,mn=Math.round(fr*60/180),mx=Math.round(fr*60/60);let bl=0,bs=0;
  for(let l=mn;l<=mx;l++){let c=0;for(let i=l;i<n;i++)c+=f[i]*f[i-l];c/=Math.sqrt(l);if(c>bs){bs=c;bl=l}}
  const per=bl/fr,out=[];
  const minGap=per?Math.max(.22,per*.45):.28;
  pk.sort((x,y)=>y.v-x.v);
  const kept=[];for(const q of pk){if(kept.every(o=>Math.abs(o-q.t)>=minGap))kept.push(q.t)}
  kept.sort((x,y)=>x-y);
  // pull each beat toward the nearest tempo-grid point when it is close, so the grid stays steady
  if(per&&kept.length>3){const t0=kept[0];kept.forEach(t=>{const g=t0+Math.round((t-t0)/per)*per;out.push(+(Math.abs(g-t)<per*.18?g:t).toFixed(2))})}else kept.forEach(t=>out.push(+t.toFixed(2)));
  return out.filter((t,i)=>!i||t-out[i-1]>.15)}
const CATS=['All','Camera','Blur','Color','Light','Glitch','Distort','Transition','Pattern','Edges','Key','Presets','Recipes','Guide'];
const CATIC={Camera:'zoom',Blur:'glow',Color:'spark',Light:'flash',Glitch:'glitch',Distort:'shake',Transition:'film',Pattern:'film',Edges:'spark',Key:'glow'};
const LOOKS=new Set(['bw','sepia','vig','grain','vhs','scan','vivid','mirror']);
const TANIMS=[['pop','Pop'],['fade','Fade'],['rise','Rise'],['type','Typewriter'],['bounce','Bounce'],['glitch','Glitch'],['spin','Spin'],['slide','Slide'],['spacing','Spacing'],['scramble','Scramble'],['rand','Randomizer'],['countup','Count up'],['countdown','Count down'],['jitter','Jitter'],['char','Char reveal'],['word','Word reveal'],['tglow','Glow'],['tshadow','Shadow'],['wave','Wave'],['shake','Shake'],['flicker','Flicker'],['kinetic','Kinetic'],['caption','Captions']];
const TSTYLES=[['serif','Serif'],['bold','Bold'],['mono','Mono'],['neon','Neon']];
const OVH=['flash','black','vig','scan','grain','leak','glow','mul','scr','ovl','sft','dod','dif','dots','stripes','check','tiles','clouds','stars','rays','glint','badd','bdar','blit','bhrd','bexc'].map(k=>`<i class="ov ${k}" data-k="${k}"></i>`).join('');

function compose(list,T,pv,Tj){
  const o={t:[],f:[],o:{},c:''};
  list.forEach(e=>{
    const d=FX[e.type];if(!d)return;
    const p=Math.min(1,Math.max(0,(T-e.t)/e.d));
    if(d[2]==='kf'){const k=kfEval(e.kf||KF0(),p);o.t.push(`translate(${k.x}%,${k.y}%) rotate(${k.r}deg) scale(${k.s/100})`);return}
    const s=d[2]==='pulse'?Math.sin(Math.PI*p):d[2]==='in'?p:d[2]==='out'?1-p:Math.min(1,p*8,(1-p)*8);
    const v=(EASE[e.ease||d[5]||'inout'])(s)*(e.amt==null?70:e.amt)/100;
    const r=d[4](v,{p,T:Tj==null?T:Tj,pv,e});
    if(r.t)o.t.push(r.t);if(r.f)o.f.push(r.f);if(r.c)o.c=r.c;
    for(const k in r.o||{})o.o[k]=Math.max(o.o[k]||0,r.o[k]);
  });
  return o;
}
function paint(media,ovs,o){
  media.style.transform=o.t.join(' ')||'none';media.style.filter=o.f.join(' ')||'none';media.style.clipPath=o.c||'none';
  ovs.forEach(el=>{el.style.opacity=Math.min(1,o.o[el.dataset.k]||0)});
}
function textFx(e,p,T){
  const a=e.anim||'pop',i=Math.min(1,p*4),o=Math.min(1,p*6,(1-p)*6),b=EASE.back(i);
  switch(a){
    case 'spacing':return{op:o,ls:((1-EASE.out(Math.min(1,p*3)))*.6)+'em'};
    case 'scramble':{const L=e.label,n=Math.floor(L.length*Math.min(1,p*2)),rr=rng(Math.floor(T*18)+7),G='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#%&';return{op:o,txt:L.slice(0,n)+L.slice(n).replace(/\S/g,()=>G[Math.floor(rr()*G.length)])}}
    case 'rand':{const L=e.label,rr=rng(Math.floor(T*18)+3),G='ABCDEFGHIJKLMNOPQRSTUVWXYZ',q=Math.min(1,p*2);return{op:o,txt:[...L].map((ch,k)=>ch===' '||q>((k*37)%L.length)/L.length+.05?ch:G[Math.floor(rr()*G.length)]).join('')}}
    case 'countup':case 'countdown':{const m=e.label.match(/\d+/),N=m?+m[0]:100,q=EASE.out(Math.min(1,p*2)),n=Math.round(N*(a==='countup'?q:1-q));return{op:o,txt:m?e.label.replace(/\d+/,n):String(n)}}
    case 'jitter':return{op:o,tf:`translate(${J(T,150)*3}px,${J(T,97)*3}px) rotate(${J(T,61)*.8}deg)`};
    case 'char':{const q=EASE.out(Math.min(1,p*2.5));return{op:o,txt:e.label.slice(0,Math.ceil(e.label.length*q)),tf:`scale(${1+.04*Math.sin(q*30)*(1-q)})`}}
    case 'word':{const w=e.label.split(' '),k=Math.ceil(w.length*Math.min(1,p*2.4));return{op:o,txt:w.slice(0,k).join(' ')}}
    case 'tglow':return{op:o,sh:`0 0 ${14+10*Math.sin(T*6)}px rgba(233,207,147,.95)`};
    case 'tshadow':return{op:o,sh:`${8*i}px ${8*i}px 0 rgba(0,0,0,.85)`};
    case 'wave':return{op:o,tf:`translateY(${Math.sin(T*6)*10}px) rotate(${Math.sin(T*3)*2}deg)`};
    case 'shake':return{op:o,tf:`translate(${J(T,200)*6}px,${J(T,170)*6}px)`};
    case 'flicker':return{op:o*(J(T,300)>-.25?1:.15)};
    case 'kinetic':{const w=e.label.split(' '),k=Math.min(w.length-1,Math.floor(p*w.length)),l=(p*w.length)%1;return{op:1,txt:w[k],tf:`scale(${.6+.4*EASE.back(Math.min(1,l*3))})`}}
    case 'caption':{const w=e.label.split(' '),k=Math.max(1,Math.ceil(w.length*Math.min(1,p*2.4)));return{op:o,txt:w.slice(Math.max(0,k-3),k).join(' ')}}
    case 'fade':return{op:Math.min(1,p*3,(1-p)*3)};
    case 'rise':return{op:o,tf:`translateY(${(1-EASE.out(i))*50}px)`};
    case 'type':return{op:1,txt:e.label.slice(0,Math.ceil(e.label.length*Math.min(1,p*2.2)))};
    case 'bounce':return{op:o,tf:`translateY(${-Math.abs(Math.sin(p*14))*(1-p)*40}px)`};
    case 'glitch':return{op:o,tf:`translate(${J(T,130)*8}px,0) skewX(${J(T,90)*8}deg)`,sh:'3px 0 #ff2d55,-3px 0 #00e5ff'};
    case 'spin':return{op:o,tf:`rotate(${(1-b)*-180}deg) scale(${b})`};
    case 'slide':return{op:o,tf:`translateX(${(1-EASE.out(i))*-120}%)`};
    default:return{op:o,tf:`scale(${.5+.5*b})`};
  }
}

/* ---------- state ---------- */
const state={style:'Cinematic',ratio:'9/16',tempo:1,opts:{cuts:true,fx:true,text:true,beat:true,captions:false},intensity:60,prompt:'Cut on the beat with punchy zooms',notes:'',events:[],nid:1};
const P={t:0,dur:24,playing:false,last:0,v:null};
const PPS=36,OFF=32;let OVS=[],sel=null,ki=0,kd=null,LY=null,EC=null,MD=null;const H={u:[],r:[],last:'[]',t:0};

function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(toast.h);toast.h=setTimeout(()=>t.classList.remove('show'),2600)}
function go(id){$$('.screen').forEach(s=>s.classList.toggle('active',s.id===id));$$('.tab').forEach(b=>b.classList.toggle('on',b.dataset.go===id));$('main').scrollTo(0,0);if(id!=='editor')pause()}
function hash(s){let h=2166136261;for(const c of s){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0}
function rng(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const CFG=(()=>{try{return JSON.parse(localStorage.getItem('kino.cfg')||'{}')}catch(e){return{}}})();
function cfgSet(k,v){CFG[k]=v;try{localStorage.setItem('kino.cfg',JSON.stringify(CFG))}catch(e){}}
function settingRow(name,desc,on,cb){const r=document.createElement('div');r.innerHTML=`<div class="t"><b>${name}</b><small>${desc}</small></div>`;const d=document.createElement('button');d.className='sw'+(on?' on':'');d.setAttribute('role','switch');d.onclick=()=>{d.classList.toggle('on');cb(d.classList.contains('on'))};r.append(d);return r}
function addAt(track,type,label,t,d,x){const e={id:state.nid++,track,type,label,t,d,amt:70,ease:(FX[type]&&FX[type][5])||'inout',...x};state.events.push(e);return e}
function starts(){return state.events.filter(e=>e.track==='video'&&e.t>0).map(e=>e.t)}

/* ---------- plan (DEMO: replace with backend/LLM output) ---------- */
function buildPlan(){
  const D=P.dur,S_=state.style,st=SET[S_],r=rng(hash(state.prompt+S_+state.tempo));
  const every=({Cinematic:5,AMV:2.2,Glitch:2.8,Smooth:4,Hype:1.6}[S_])*state.tempo;
  state.events=[];let t=0,k=1;
  if(state.opts.cuts){while(t<D-.6){let d=Math.min(every*(.8+r()*.5),D-t);if(state.beats){const nb=state.beats.find(b=>b>t+every*.6&&b<D-.3);if(nb)d=nb-t}addAt('video','clip','Clip '+k,t,d);t+=d;k++}}
  else addAt('video','clip','Full clip',0,D);
  const clips=state.events.filter(e=>e.track==='video');
  if(state.opts.fx){
    st.look.forEach(id=>addAt('fx',id,FX[id][0],0,D,{amt:45}));
    clips.forEach((c,i)=>{if(i===0)return;
      const tr=st.tr[Math.floor(r()*st.tr.length)];addAt('fx',tr,FX[tr][0],Math.max(0,c.t-.25),.5,{amt:40+state.intensity*.5});
      if(r()*100<state.intensity+25){const a=st.acc[i%st.acc.length];addAt('fx',a,FX[a][0],c.t,FX[a][2]==='hold'?.6:.5,{amt:50+state.intensity*.4})}
    });
  }
  if(state.opts.text){
    const q=state.prompt.match(/[“"](.+?)[”"]/),title=(q?q[1]:TITLES[S_]).toUpperCase();
    addAt('text','text',title,.6,2.4,{anim:st.an,tstyle:st.ts});
    addAt('text','text','THE END',Math.max(3,D-3),2.4,{anim:st.an,tstyle:st.ts});
  }
  if(state.opts.beat)(state.beats||clips.slice(1).map(c=>c.t)).forEach(t=>addAt('audio','beat','',t,.2));
}


/* ---------- AI plan (real backend, falls back to buildPlan) ---------- */
const PLAN_TRACKS=new Set(['video','fx','text','audio']);
function cleanPlan(raw){
  if(!raw||!Array.isArray(raw.events))throw new Error('bad plan');
  const D=P.dur,out=[];let id=1;
  for(const e of raw.events.slice(0,400)){
    if(!e||!PLAN_TRACKS.has(e.track))continue;
    const t=Math.min(Math.max(+e.t||0,0),D),d=Math.min(Math.max(+e.d||.5,.05),D-t||.05);
    if(e.track==='fx'&&!FX[e.type])continue;
    const x={id:id++,track:e.track,type:e.type||(e.track==='video'?'clip':e.track==='text'?'text':'beat'),label:String(e.label||(FX[e.type]&&FX[e.type][0])||e.type||'').slice(0,60),t,d,amt:Math.min(Math.max(+e.amt||70,0),100),ease:e.ease||(FX[e.type]&&FX[e.type][5])||'inout'};
    if(e.track==='text'){x.anim=TANIMS.some(a=>a[0]===e.anim)?e.anim:'pop';x.tstyle=TSTYLES.some(a=>a[0]===e.tstyle)?e.tstyle:'bold'}
    if(Array.isArray(e.kf))x.kf=e.kf.slice(0,24).map(k=>({p:Math.min(Math.max(+k.p||0,0),1),x:+k.x||0,y:+k.y||0,s:+k.s||100,r:+k.r||0,e:k.e||'inout'}));
    out.push(x);
  }
  if(!out.some(e=>e.track==='video'))throw new Error('no clips');
  state.events=out;state.nid=id;
  if(raw.summary)state.aiSummary=String(raw.summary).slice(0,300);
}
async function aiPlan(current,instruction){
  const url=(CFG.aiUrl||'').trim();if(!url)return false;
  const ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),60000);
  try{
    const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},signal:ctl.signal,body:JSON.stringify({prompt:state.prompt,notes:state.notes,style:state.style,duration:P.dur,beats:state.beats||[],opts:state.opts,intensity:state.intensity,current:current||null,instruction:instruction||null,fxTypes:Object.keys(FX)})});
    if(!r.ok)throw new Error('HTTP '+r.status);
    cleanPlan(await r.json());return true;
  }catch(e){toast('AI server unavailable. Used the offline plan.');return false}
  finally{clearTimeout(to)}
}

/* ---------- player ---------- */
function setPlayIcon(){$('#bPlay').innerHTML=ic(P.playing?'pause':'play')}
function play(){if(P.t>=P.dur-.05)seek(0);P.playing=true;P.last=performance.now();if(P.v)P.v.play();if(LY)LY.play();setPlayIcon()}
function pause(){P.playing=false;if(P.v)P.v.pause();if(LY)LY.pause();setPlayIcon()}
function seek(t){P.t=Math.max(0,Math.min(P.dur,t));if(P.v)P.v.currentTime=srcT(P.t);lyrSync();draw()}
function tick(ts){
  if(P.playing){P.t+=(ts-P.last)/1000;vSync();P.last=ts;lyrSync(true);if(P.t>=P.dur){P.t=P.dur;pause()}draw(true)}
  pvTick(ts);requestAnimationFrame(tick);
}
function draw(follow){
  const x=OFF+P.t*PPS,h=$('#head');if(h)h.style.transform=`translateX(${x}px)`;
  $('#tcur').textContent=fmt(P.t);
  const act=state.events.filter(e=>P.t>=e.t&&P.t<e.t+e.d);
  paint($('#media'),OVS,compose(act.filter(e=>e.track==='fx'),P.t,false,P.t));
  const tx=act.find(e=>e.track==='text'),to=$('#txt');
  if(tx){const r=textFx(tx,(P.t-tx.t)/tx.d,P.t),txt=r.txt==null?tx.label:r.txt,cls='txt ts-'+(tx.tstyle||'serif');
    if(to.className!==cls)to.className=cls;if(to.textContent!==txt)to.textContent=txt;
    to.style.opacity=r.op;to.style.transform=((r.tf||'')+(tx.kf?' '+kfCss(kfEval(tx.kf,(P.t-tx.t)/tx.d)):''))||'none';to.style.textShadow=r.sh||'';to.style.letterSpacing=r.ls||''}
  else to.style.opacity=0;
  const kz=act.find(e=>e.type==='kal'),kc=$('#kal');kc.style.display=kz&&P.v?'block':'none';
  if(kz&&P.v){const st=$('#stage');if(kc.width!==(st.clientWidth>>1)){kc.width=st.clientWidth>>1;kc.height=st.clientHeight>>1}kalDraw(kc.getContext('2d'),P.v,P.v.videoWidth,P.v.videoHeight,kc.width,kc.height,kalN(kz),P.t*.4)}
  const cu=act.find(e=>e.type==='box3d'),on3=!!(cu&&P.v&&P.v.videoWidth);$('#cube3d').style.display=on3?'block':'none';$('#media').style.visibility=on3?'hidden':'visible';
  if(on3){const q=P.t-cu.t;cubeDraw(P.v,q*60*(cu.amt==null?70:cu.amt)/70,Math.sin(q*1.2)*15)}
  const ec=act.find(e=>e.type==='echo');
  if(EC){EC.style.display=ec?'block':'none';if(ec){EC.style.opacity=.55*(ec.amt==null?70:ec.amt)/100;const et=Math.max(0,srcT(P.t-.3));
    if(!P.playing||Math.abs(EC.currentTime-et)>.2)EC.currentTime=et;if(P.playing&&EC.paused)EC.play();if(!P.playing&&!EC.paused)EC.pause()}}
  const clip=act.find(e=>e.track==='video');
  $('#stage').style.setProperty('--h',(((clip&&parseInt(clip.label.split(' ')[1]))||1)*47+250)%360);
  if(sel&&isKF(sel)&&$('#insp').classList.contains('on')){const q=(P.t-sel.t)/sel.d,h=$('#kfh');h.style.display=q>=0&&q<=1?'block':'none';h.style.left=q*100+'%'}
  if(follow){const sc=$('#tlscroll');sc.scrollLeft=x-sc.clientWidth/2}
}
function pvTick(ts){
  const T=ts/1000,L=1.8,p=(T%L)/L;
  $$('.pvm').forEach(m=>{if(!m.offsetParent)return;
    paint(m,$$('.ov',m.parentElement),compose(pvEv(m.closest('.fxc')),p,true,T))});
}

/* ---------- timeline + plan ---------- */
function pack(list){const rows=[],out=new Map();list.slice().sort((a,b)=>a.t-b.t).forEach(e=>{let r=rows.findIndex(end=>end<=e.t+.001);if(r<0){r=rows.length;rows.push(0)}rows[r]=e.t+e.d;out.set(e.id,r)});return{n:Math.max(1,rows.length),out}}
function renderTL(){
  const inner=$('#tlin');inner.style.width=(OFF+P.dur*PPS+24)+'px';
  let h='<div class="ruler" id="ruler">';
  for(let s=0;s<=P.dur;s+=2)h+=`<i style="left:${OFF+s*PPS}px">${fmt(s)}</i>`;
  h+='</div>';
  [['video','film'],['fx','spark'],['text','type'],['audio','music']].forEach(([l,icn])=>{
    const list=state.events.filter(e=>e.track===l),pk=l==='fx'||l==='text'?pack(list):{n:1,out:new Map()},H=l==='fx'||l==='text'?pk.n*30+8:38;
    h+=`<div class="lane" style="height:${H}px"><span class="ll">${ic(icn)}</span>`;
    if(l==='audio')for(let b=0;b<P.dur;b+=.5)h+=`<b class="bt" style="left:${OFF+b*PPS}px;height:${6+((b*7)%5)*4}px"></b>`;
    list.forEach(e=>{
      const ico=e.track==='fx'?ic(CATIC[FX[e.type][1]]):e.track==='text'?ic('type'):e.track==='video'?ic('scissors'):'';
      h+=`<div class="blk b-${l}" data-id="${e.id}" style="left:${OFF+e.t*PPS}px;width:${Math.max(20,e.d*PPS-2)}px;top:${4+(pk.out.get(e.id)||0)*30}px">${ico}${e.track==='fx'?FX[e.type][0]:e.label}${kfMarks(e)}</div>`;
    });
    h+='</div>';
  });
  h+='<div class="head" id="head"></div>';
  inner.innerHTML=h;$('#tdur').textContent=fmt(P.dur);
}
function renderPlan(){
  const list=state.events.filter(e=>e.track==='fx'||e.track==='text').sort((a,b)=>a.t-b.t);
  $('#planN').textContent=`${state.events.filter(e=>e.track==='video').length} cuts · ${list.length} moves`;
  $('#plan').innerHTML=list.map(e=>{const fx=e.track==='fx',n=fx?FX[e.type][0]:e.label;
    return `<div class="item" data-id="${e.id}"><div class="thumb" style="background:${fx?'rgba(233,207,147,.14);color:var(--gold)':'rgba(139,120,255,.2);color:#cfc7ff'}">${ic(fx?CATIC[FX[e.type][1]]:'type')}</div><div class="grow"><b>${n}</b><small>${fx?FX[e.type][1]:'Title · '+(e.anim||'pop')} · ${fmt(e.t)} · ${e.d.toFixed(1)}s</small></div><button class="del" data-del="${e.id}" aria-label="Remove">${ic('x')}</button></div>`}).join('')||'<p class="sub">No effects yet. Tap + Effect or ask the AI below.</p>';
}
function renderAll(){renderTL();renderPlan();draw();commit()}

/* ---------- effect catalogue ---------- */
function renderCatalog(catsEl,gridEl){
  const cur=catsEl.dataset.cat||'All',PR=cur==='Presets'||cur==='Recipes';
  catsEl.innerHTML=CATS.map(c=>`<button class="chip${c===cur?' on':''}" data-cat="${c}">${c}</button>`).join('');
  gridEl.innerHTML=PR?presetCards(cur):cur==='Guide'?guideHtml():Object.keys(FX).filter(k=>(cur==='All'||FX[k][1]===cur)&&hit(FX[k].slice(0,4).join(' ')+' '+k)).map(k=>`<div class="fxc" data-fx="${k}"><div class="pv"><div class="pvm"></div><div class="ovp">${OVH}</div></div><b>${FX[k][0]}</b><small>${FX[k][3]}</small><button data-add="${k}">Add at playhead</button></div>`).join('')+(cur==='All'&&Q?presetCards('*'):'');
}
function addEffect(id){const d=FX[id];addAt('fx',id,d[0],P.t,d[2]==='kf'?3:d[2]==='hold'?2:d[1]==='Transition'?.8:1,d[2]==='kf'?{kf:KF0()}:{});renderAll();toast(d[0]+' added at '+fmt(P.t))}
function addTitle(anim){addAt('text','text','NEW TITLE',P.t,2.2,{anim:anim||'pop',tstyle:'serif'});renderAll();toast('Title added at '+fmt(P.t))}

/* ---------- inspector (like keyframe panel) ---------- */
function chips(list,cur,attr){return list.map(([k,n])=>`<button class="chip${cur===k?' on':''}" ${attr}="${k}">${n}</button>`).join('')}
function fillInsp(){
  const isT=sel.track==='text';renderKF();
  $('#inCat').textContent=isT?'Title':FX[sel.type][1];$('#inName').textContent=isT?'Text & animation':FX[sel.type][0];
  $('#inTextBox').style.display=isT?'block':'none';$('#rAbox').style.display=isT||isKF(sel)?'none':'block';$('#easeBox').style.display=isKF(sel)?'none':'block';
  if(document.activeElement!==$('#inTxt'))$('#inTxt').value=sel.label;
  $('#inAnim').innerHTML=chips(TANIMS,sel.anim||'pop','data-an');$('#inSty').innerHTML=chips(TSTYLES,sel.tstyle||'serif','data-ts');
  $('#inEase').innerHTML=chips(EASES,sel.ease||'inout','data-ea');
  const R=(id,v,mx)=>{const el=$('#'+id);if(mx)el.max=mx;el.value=v};
  R('rS',sel.t,P.dur);R('rD',sel.d);R('rA',sel.amt==null?70:sel.amt);
  $('#vS').textContent=fmt(sel.t);$('#vD').textContent=sel.d.toFixed(1)+'s';$('#vA').textContent=(sel.amt==null?70:sel.amt)+'%';
}
const isKF=e=>!!(e&&((FX[e.type]&&FX[e.type][2]==='kf')||(e.track==='text'&&e.kf)));
function kfSeek(){pause();seek(sel.t+sel.kf[ki].p*sel.d)}
function renderKF(){
  $('#trkBtn').style.display=sel&&sel.type==='mask'?'block':'none';const on=isKF(sel);$('#kfBox').style.display=on?'block':'none';$('#insp').classList.toggle('kfmode',on);
  if(!on)return;
  if(!sel.kf)sel.kf=KF0();ki=Math.max(0,Math.min(ki,sel.kf.length-1));const k=sel.kf[ki];
  $('#kfPts').innerHTML=sel.kf.map((q,i)=>`<i class="kfp${i===ki?' on':''}" style="left:${q.p*100}%"></i>`).join('');
  $('#kfSl').innerHTML=KFP.map(([id,n,u,mn,mx])=>`<label class="lbl">${n} <b id="kv-${id}">${Math.round(k[id])}${u}</b></label><input type="range" data-kp="${id}" min="${mn}" max="${mx}" step="1" value="${k[id]}">`).join('');
  $('#kfEaseW').style.display=ki?'block':'none';$('#kfEase').innerHTML=chips(EASES,k.e||'inout','data-ke');
  $('#kfDel').disabled=sel.kf.length<2;
}
function openInsp(id){const e=state.events.find(x=>x.id==id);if(!e||e.track==='video'||e.track==='audio')return;sel=e;ki=0;fillInsp();$('#insp').classList.add('on');if(isKF(e)){kfSeek();$('main').scrollTo({top:0,behavior:'smooth'})}}

/* ---------- revise chat ---------- */
function say(txt,who){const m=document.createElement('div');m.className='msg '+who;m.textContent=txt;const l=$('#log');l.append(m);while(l.children.length>4)l.firstChild.remove()}
const KW=[[/glow|bloom|dream/,'glow'],[/shake|impact|hit/,'shake'],[/zoom blur|radial/,'rblur'],[/zoom|punch/,'zoom'],[/rgb|chromatic|split/,'rgb'],[/vhs|tape|retro/,'vhs'],[/glitch/,'glitch'],[/motion blur/,'mblur'],[/blur/,'blur'],[/black.?(and|&)?.?white|b&w|mono/,'bw'],[/sepia|vintage/,'sepia'],[/grain|film/,'grain'],[/vignette/,'vig'],[/strobe/,'strobe'],[/flash/,'flash'],[/wave|ripple|liquid/,'wave'],[/spin|rotate/,'spin'],[/mirror|flip/,'mirror'],[/leak/,'leak'],[/dip|fade/,'dip'],[/whip/,'whip']];
async function revise(q){
  if(CFG.aiUrl){say('Thinking…','ai');if(await aiPlan(state.events,q)){renderAll();say(state.aiSummary||'Updated the edit.','ai');return}}
  const s=q.toLowerCase();let m;
  if(/fast|quick|snappy|tight|speed/.test(s)){state.tempo=Math.max(.4,state.tempo*.75);buildPlan();m='Tightened the pacing. Cuts are about 25% shorter.'}
  else if(/slow|calm|relax|breathe/.test(s)){state.tempo=Math.min(2,state.tempo*1.3);buildPlan();m='Eased the pacing with longer shots and a softer rhythm.'}
  else if(/remove|clear|no (fx|effects)/.test(s)){state.events=state.events.filter(e=>e.track!=='fx');m='Cleared all effects.'}
  else if(/title|text|caption/.test(s)){const a=TANIMS.find(x=>s.includes(x[0]));addTitle(a&&a[0]);m='Dropped a new title at the playhead.'}
  else{const hit=KW.find(k=>k[0].test(s));
    if(hit){const id=hit[1],d=FX[id];
      if(LOOKS.has(id))addAt('fx',id,d[0],0,P.dur,{amt:55});else starts().forEach(t=>addAt('fx',id,d[0],Math.max(0,t-(d[1]==='Transition'?.25:0)),d[2]==='hold'?.6:d[1]==='Transition'?.5:.8));
      m=LOOKS.has(id)?`Applied ${d[0]} across the whole video.`:`Added ${d[0]} on every cut.`}
    else{state.notes+='\n'+q;m='Noted. Add an AI server in Settings and I will re-plan with this.'}}
  renderAll();say(m,'ai');
}

/* ---------- generate + export ---------- */
async function generate(){
  state.prompt=$('#prompt').value.trim()||state.prompt;state.notes=$('#notes').value;
  const ov=$('#proc'),steps=$$('li',ov);ov.classList.add('on');
  for(const s of steps){s.classList.add('now');await wait(800);s.classList.remove('now');s.classList.add('done')}
  state.tempo=1;if(!(await aiPlan()))buildPlan();renderAll();$('#projName').innerHTML=`${state.style} <em>edit</em>`;
  ov.classList.remove('on');steps.forEach(s=>s.className='');go('editor');seek(0);toast('Edit ready. Hit play.');
}
function openSheet(on){$('#sheet').classList.toggle('on',on)}
async function doExport(){
  const b=$('#doExport'),bar=$('#bar i'),v=P.v;
  if(!v||!window.MediaRecorder){toast('Import a video first. Export records it with your effects.');return}
  const H=({'720p':720,'1080p':1080,'4K':2160})[$('#resSeg .on').textContent]||1080,fps=+$('#fpsSeg .on').textContent||30,
    rc=$('#stage').getBoundingClientRect(),W=Math.round(H*rc.width/rc.height/2)*2;
  const CP=window.Capacitor&&window.Capacitor.Plugins;
  if(CP&&CP.KinoRender&&CP.Filesystem&&P.file){b.disabled=true;b.textContent='Rendering natively…';
    try{const data=await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(String(r.result).split(',')[1]);r.onerror=rej;r.readAsDataURL(P.file)});
      const w=await CP.Filesystem.writeFile({path:'kino-src.mp4',data,directory:'CACHE'}),o=await CP.Filesystem.getUri({path:'kino-out.mp4',directory:'CACHE'}),outPath=o.uri.replace('file://','');
      let l2=null;
      if(LY&&P.file2){const d2=await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(String(r.result).split(',')[1]);r.onerror=rej;r.readAsDataURL(P.file2)});
        l2=(await CP.Filesystem.writeFile({path:'kino-layer2.mp4',data:d2,directory:'CACHE'})).uri}
      await CP.KinoRender.render({src:w.uri,out:outPath,events:state.events,height:H,fps,layer2Src:l2,blend:LB,opacity:LO});
      b.disabled=false;b.textContent='Render video';openSheet(false);
      if(CP.Share){try{await CP.Share.share({title:'KINO edit',files:[o.uri]});toast('Rendered. Choose where to save it.');return}catch(e){}}
      toast('Saved '+outPath);return}
    catch(err){toast('Native render failed ('+(err.message||err)+'). Using web export.')}}

  const cv=document.createElement('canvas');cv.width=W;cv.height=H;const g=cv.getContext('2d'),st=cv.captureStream(fps);
  try{(v.captureStream?v.captureStream():new MediaStream()).getAudioTracks().forEach(t=>st.addTrack(t))}catch(e){}
  const mt=MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')?'video/webm;codecs=vp9,opus':'video/webm',rec=new MediaRecorder(st,{mimeType:mt}),ch=[];
  rec.ondataavailable=e=>{if(e.data.size)ch.push(e.data)};
  const cover=(m,mw,mh)=>{const s=Math.max(W/mw,H/mh);g.drawImage(m,(W-mw*s)/2,(H-mh*s)/2,mw*s,mh*s)};
  const px=s=>s.replace(/translate\(([-\d.e]+)%,\s*([-\d.e]+)%\)/g,(_,a,c)=>`translate(${a*W/100}px,${c*H/100}px)`).replace(/translateX\(([-\d.e]+)%\)/g,(_,a)=>`translateX(${a*W/100}px)`);
  const mk=(n,f)=>{const c=document.createElement('canvas');c.width=c.height=n;f(c.getContext('2d'),n);return g.createPattern(c,'repeat')},
    LG=(a,b,c,d,s)=>{const q=g.createLinearGradient(a,b,c,d);s.forEach(([o,k])=>q.addColorStop(o,k));return q},
    RG=(x,y,r0,r,s)=>{const q=g.createRadialGradient(x,y,r0,x,y,r);s.forEach(([o,k])=>q.addColorStop(o,k));return q},
    OV2={mul:['multiply',()=>LG(W*.3,0,W*.7,H,[[0,'#ffb36b'],[1,'#7a5cff']])],
     scr:['screen',()=>RG(W*.7,H*.3,0,Math.max(W,H)*.8,[[0,'#7fd6ff'],[.55,'#ff6ad5'],[1,'rgba(255,106,213,0)']])],
     ovl:['overlay',()=>LG(0,0,0,H,[[0,'#00c2c7'],[1,'#ff7a18']])],
     sft:['soft-light',()=>LG(0,0,W,H,[[0,'#ff9ecb'],[1,'#ffd6a0']])],
     dod:['color-dodge',()=>RG(W/2,H*.4,0,Math.max(W,H)*.7,[[0,'#fff2cc'],[.6,'#ff8a4c'],[1,'rgba(255,138,76,0)']])],
     dif:['difference',()=>LG(0,0,W,0,[[0,'#3a00ff'],[1,'#00ffa3']])],
     leak:['screen',()=>LG(0,0,W,H,[[0,'rgba(255,120,40,.95)'],[.45,'rgba(255,60,120,.4)'],[.7,'rgba(255,60,120,0)']])],
     glow:['source-over',()=>RG(W/2,H/2,Math.min(W,H)*.4,Math.hypot(W,H)*.5,[[0,'rgba(233,207,147,0)'],[1,'rgba(233,207,147,.85)']])],
     scan:['source-over',()=>mk(4,(x,n)=>{x.fillStyle='rgba(0,0,0,.4)';x.fillRect(0,0,n,1)})],
     grain:['overlay',()=>mk(128,(x,n)=>{const d=x.createImageData(n,n);for(let i=0;i<d.data.length;i+=4){d.data[i]=d.data[i+1]=d.data[i+2]=Math.random()*255;d.data[i+3]=255}x.putImageData(d,0,0)})],
     dots:['multiply',()=>mk(7,x=>{x.fillStyle='#000';x.beginPath();x.arc(3.5,3.5,2.5,0,6.2832);x.fill()})],
     stripes:['source-over',()=>mk(28,(x,n)=>{x.fillStyle='rgba(0,0,0,.55)';x.fillRect(0,0,14,n)})],
     check:['source-over',()=>mk(120,x=>{x.fillStyle='rgba(0,0,0,.5)';x.fillRect(0,0,60,60);x.fillRect(60,60,60,60)})],
     tiles:['source-over',()=>mk(80,(x,n)=>{x.fillStyle='rgba(0,0,0,.6)';x.fillRect(0,0,n,3);x.fillRect(0,0,3,n)})],
     clouds:['screen',()=>mk(512,(x,n)=>{[[.25,.3,.2,.55],[.7,.6,.22,.45],[.45,.85,.17,.4]].forEach(([a,b,r,o])=>{const q=x.createRadialGradient(a*n,b*n,0,a*n,b*n,r*n*1.6);q.addColorStop(0,`rgba(255,255,255,${o})`);q.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=q;x.fillRect(0,0,n,n)})})],
     stars:['screen',()=>mk(256,(x,n)=>{const r=rng(5);for(let i=0;i<26;i++){x.fillStyle=i%3?'#fff':'#cfe';x.beginPath();x.arc(r()*n,r()*n,.7+r()*1.2,0,6.2832);x.fill()}})],
     rays:['screen',()=>{try{const q=g.createConicGradient(Math.PI/2,W/2,-H*.1);for(let i=0;i<40;i++){q.addColorStop(i/40,i%3?'rgba(255,240,200,0)':'rgba(255,240,200,.55)');q.addColorStop(Math.min(1,(i+.9)/40),i%3?'rgba(255,240,200,0)':'rgba(255,240,200,.55)')}return q}catch(e){return'rgba(0,0,0,0)'}}],
     glint:['screen',()=>RG(W*.72,H*.28,0,H*.2,[[0,'#fff'],[.3,'rgba(255,255,255,.6)'],[1,'rgba(255,255,255,0)']])],
     badd:['lighter',()=>LG(0,0,0,H,[[0,'#402010'],[1,'#102040']])],
     bdar:['darken',()=>LG(0,0,W,H,[[0,'#3a6cff'],[1,'#ff6a3a']])],
     blit:['lighten',()=>LG(0,0,W,H,[[0,'#ffcf6a'],[1,'#6affd0']])],
     bhrd:['hard-light',()=>LG(0,0,W,H,[[0,'#ff3a8a'],[1,'#3a8aff']])],
     bexc:['exclusion',()=>LG(0,0,W,0,[[0,'#7a00ff'],[1,'#00c8ff']])]},pc={};
  const clipTo=c=>{if(!c)return;let m=c.match(/^circle\(([-\d.e]+)%/);g.beginPath();
    if(m)g.arc(W/2,H/2,+m[1]/100*Math.hypot(W,H)/Math.SQRT2,0,6.2832);
    else if(m=c.match(/^polygon\((.*)\)$/))m[1].split(',').forEach((q,i)=>{const[a,b]=q.trim().split(' ').map(parseFloat);i?g.lineTo(a*W/100,b*H/100):g.moveTo(a*W/100,b*H/100)});
    else if(m=c.match(/^inset\(([^)]*)\)/)){const v=m[1].split(' round ')[0].trim().split(/\s+/).map(x=>parseFloat(x)/100),
      [t,ri,b,l]=v.length===1?[v[0],v[0],v[0],v[0]]:v.length===2?[v[0],v[1],v[0],v[1]]:v.length===3?[v[0],v[1],v[2],v[1]]:v;g.rect(l*W,t*H,W-(l+ri)*W,H-(t+b)*H)}
    else return;g.clip()};
  b.disabled=true;b.textContent='Rendering…';rec.start(250);seek(0);play();
  await new Promise(done=>{const step=()=>{
    const act=state.events.filter(e=>P.t>=e.t&&P.t<e.t+e.d),o=compose(act.filter(e=>e.track==='fx'),P.t,false,P.t);
    g.setTransform(1,0,0,1,0,0);g.globalAlpha=1;g.globalCompositeOperation='source-over';g.filter='none';g.fillStyle='#000';g.fillRect(0,0,W,H);
    g.save();try{const m=new DOMMatrix(px(o.t.join(' '))||'none');g.translate(W/2,H/2);g.transform(m.a,m.b,m.c,m.d,m.e,m.f);g.translate(-W/2,-H/2)}catch(e){}
    clipTo(o.c);g.filter=o.f.join(' ')||'none';cover(v,v.videoWidth||W,v.videoHeight||H);g.restore();
    const cx3=act.find(e=>e.type==='box3d');if(cx3)cubeDrawC(g,v,W,H,(P.t-cx3.t)*60*(cx3.amt==null?70:cx3.amt)/70,900*W/$('#stage').clientWidth);
    const kz=act.find(e=>e.type==='kal');if(kz)kalDraw(g,v,v.videoWidth,v.videoHeight,W,H,kalN(kz),P.t*.4);
    if(EC&&EC.style.display==='block'){g.save();g.globalAlpha=+EC.style.opacity;g.globalCompositeOperation='screen';cover(EC,EC.videoWidth||W,EC.videoHeight||H);g.restore()}
    if(LY){g.save();g.globalAlpha=LO;g.globalCompositeOperation=BL[LB]==='normal'?'source-over':BL[LB];cover(LY,LY.videoWidth||W,LY.videoHeight||H);g.restore()}
    const f=o.o.flash||0,k=o.o.black||0,vg=o.o.vig||0;
    if(f){g.fillStyle=`rgba(255,255,255,${Math.min(1,f)})`;g.fillRect(0,0,W,H)}
    if(k){g.fillStyle=`rgba(0,0,0,${Math.min(1,k)})`;g.fillRect(0,0,W,H)}
    if(vg){const gr=g.createRadialGradient(W/2,H/2,H*.3,W/2,H/2,H*.85);gr.addColorStop(0,'rgba(0,0,0,0)');gr.addColorStop(1,`rgba(0,0,0,${.9*Math.min(1,vg)})`);g.fillStyle=gr;g.fillRect(0,0,W,H)}
    for(const k in OV2){const a=Math.min(1,o.o[k]||0);if(a){g.save();g.globalAlpha=a;g.globalCompositeOperation=OV2[k][0];g.fillStyle=pc[k]||(pc[k]=OV2[k][1]());g.fillRect(0,0,W,H);g.restore()}}
    const tx=act.find(e=>e.track==='text'),to=$('#txt'),op=+to.style.opacity;
    if(tx&&op>0){g.save();g.globalAlpha=op;g.fillStyle='#fff';const fs=Math.round(H*.045);g.font=`italic ${fs}px Georgia,serif`;g.textAlign='center';
      const sh=to.style.textShadow||'',col=(sh.match(/rgba?\([^)]*\)|#[0-9a-f]{3,8}/i)||['rgba(233,207,147,.8)'])[0],nm=(sh.match(/-?[\d.]+px/g)||[]).map(parseFloat);
      g.shadowColor=col;g.shadowOffsetX=nm[0]||0;g.shadowOffsetY=nm[1]||0;g.shadowBlur=nm.length>2?nm[2]:(sh?0:H*.02);
      try{g.letterSpacing=(parseFloat(to.style.letterSpacing)||0)*fs+'px'}catch(e){}
      g.translate(W/2,H*.84);try{g.transform(new DOMMatrix(px(to.style.transform||'none')))}catch(e){}
      g.fillText(to.textContent,0,0,W*.9);g.restore()}
    bar.style.width=Math.min(100,P.t/P.dur*100)+'%';
    P.playing?requestAnimationFrame(step):done()};step()});
  const stopped=new Promise(r=>{rec.onstop=r});rec.stop();await stopped;
  const blob=new Blob(ch,{type:'video/webm'}),file=new File([blob],'kino-edit.webm',{type:'video/webm'});
  b.disabled=false;b.textContent='Render video';bar.style.width='0';openSheet(false);
  const CPX=window.Capacitor&&window.Capacitor.Plugins;
  if(CPX&&CPX.Filesystem&&CPX.Share){
    try{const data=await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(String(r.result).split(',')[1]);r.onerror=rej;r.readAsDataURL(blob)});
      const w=await CPX.Filesystem.writeFile({path:'kino-edit.webm',data,directory:'CACHE'});
      await CPX.Share.share({title:'KINO edit',files:[w.uri]});toast('Exported. Choose where to save it.');return}
    catch(err){toast('Could not save the file ('+(err.message||err)+')');return}}
  try{if(navigator.canShare&&navigator.canShare({files:[file]})){await navigator.share({files:[file],title:'KINO edit'});return}}catch(e){}
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='kino-edit.webm';a.click();toast('Exported kino-edit.webm');
}

/* ---------- init ---------- */
function init(){
  S.mbs=$('#mbs');S.pxF=$('#pxF');S.pxC=$('#pxC');S.pxM=$('#pxM');S.rR=$('#rgbR');S.rB=$('#rgbB');S.wd=$('#wd');S.wt=$('#wt');
  $('#ovs').innerHTML=OVH;OVS=$$('#ovs .ov');
  const hr=new Date().getHours();$('#greet').textContent=hr<12?'Good morning':hr<18?'Good afternoon':'Good evening';
  $('#homeStyles').innerHTML=STYLES.map(s=>`<button class="scard" data-style="${s[0]}" style="background:${s[2]}"><b>${s[0]}</b><small>${s[1]}</small></button>`).join('');
  $('#tpls').innerHTML=[['Beat Drop','AMV'],['Hero Reveal','Cinematic'],['Hook Intro','Hype'],['Dream Walk','Smooth']].map(t=>{const s=STYLES.find(x=>x[0]===t[1]);return `<button class="scard" data-style="${t[1]}" style="background:${s[2]}"><b>${t[0]}</b><small>${t[1]} template</small></button>`}).join('');
  $('#recent').innerHTML=PROJECTS.map(p=>`<button class="item" data-go="editor"><div class="thumb" style="background:${p[2]}">${ic('play')}</div><div class="grow"><b>${p[0]}</b><small>${p[1]}</small></div></button>`).join('');
  $('#styles').innerHTML=STYLES.map(s=>`<button class="chip${s[0]===state.style?' on':''}" data-pick="${s[0]}">${s[0]}</button>`).join('');
  $('#quick').innerHTML=['Faster cuts','More glow','RGB split','VHS look','Punch zoom','Black and white','Add title','Clear effects'].map(q=>`<button class="chip" data-q="${q}">${q}</button>`).join('');
  $('#tanims').innerHTML=TANIMS.map(a=>`<button class="chip" data-tanim="${a[0]}">${a[1]}</button>`).join('');
  $('#fxCount').textContent=Object.keys(FX).length+' effects · '+TANIMS.length+' text animations · '+PRESETS.length+' presets & recipes';
  renderCatalog($('#libCats'),$('#fxgrid'));

  OPTS.forEach(o=>$('#opts').append(settingRow(o[1],o[2],state.opts[o[0]],v=>state.opts[o[0]]=v)));
  [['Haptic feedback','Small vibration when you tap or scrub','haptic',true],['Keep original audio','Use your video’s sound under the edit','keepAudio',true],['Smart suggestions','AI proposes extra moves after each edit','suggest',true]].forEach(r=>$('#set1').append(settingRow(r[0],r[1],CFG[r[2]]??r[3],v=>{cfgSet(r[2],v);if(r[2]==='haptic'&&v&&navigator.vibrate)navigator.vibrate(15)})));
  {const r=document.createElement('div');r.innerHTML='<div class="t"><b>AI server</b><small>Address of your KINO server (see server/README.md). Empty = offline sample plan.</small></div>';const i=document.createElement('input');i.id='aiUrl';i.type='url';i.placeholder='https://your-server.example/plan';i.value=CFG.aiUrl||'';i.style.cssText='width:100%;margin-top:8px;padding:10px;border-radius:10px;border:1px solid #333;background:#151518;color:inherit';i.onchange=()=>{cfgSet('aiUrl',i.value.trim());toast(i.value.trim()?'AI server saved':'Using offline plan')};r.append(i);$('#set1').append(r)}
  [['Watermark','Show a small KINO mark on exports (needs a future export update)','watermark',false],['Save to gallery','Copy finished videos to your phone gallery','gallery',true],['High quality preview','Sharper preview, uses more battery','hq',false]].forEach(r=>$('#set2').append(settingRow(r[0],r[1],CFG[r[2]]??r[3],v=>cfgSet(r[2],v))));

  document.addEventListener('click',e=>{
    const T=t=>e.target.closest(t);let x;
    if(x=T('[data-go]')){go(x.dataset.go);return}
    if(x=T('[data-style]')){state.style=x.dataset.style;$$('#styles .chip').forEach(c=>c.classList.toggle('on',c.dataset.pick===state.style));go('create');toast(state.style+' style selected');return}
    if(x=T('[data-pick]')){state.style=x.dataset.pick;$$('#styles .chip').forEach(c=>c.classList.toggle('on',c===x));return}
    if(x=T('[data-q]')){say(x.dataset.q,'me');revise(x.dataset.q);return}
    if(x=T('[data-cat]')){const bar=x.parentElement;bar.dataset.cat=x.dataset.cat;renderCatalog(bar,bar.id==='libCats'?$('#fxgrid'):$('#pickGrid'));return}
    if(x=T('[data-act]')){ACT[x.dataset.act]();$('#pick').classList.remove('on');return}
    if(x=T('[data-ease]')){if(sel&&sel.track==='fx'){sel.ease=x.dataset.ease;fillInsp();renderAll();toast('Curve set on the selected effect')}else toast('Open an effect on the timeline first, then tap a curve');return}
    if(x=T('[data-info]')){toast(x.dataset.info);return}
    if(x=T('[data-preset]')){addPreset(+x.dataset.preset);$('#pick').classList.remove('on');return}
    if(x=T('[data-add]')){addEffect(x.dataset.add);$('#pick').classList.remove('on');return}
    if(x=T('[data-tanim]')){addTitle(x.dataset.tanim);return}
    if(x=T('[data-del]')){state.events=state.events.filter(v=>v.id!=x.dataset.del);renderAll();return}
    if(x=T('.blk')){const ev=state.events.find(v=>v.id==x.dataset.id);if(ev)openInsp(ev.id);return}
    if(x=T('#plan .item')){const ev=state.events.find(v=>v.id==x.dataset.id);if(ev){seek(ev.t);$('main').scrollTo({top:0,behavior:'smooth'});openInsp(ev.id)}return}
    if(x=T('[data-an]')){sel.anim=x.dataset.an;fillInsp();seek(sel.t+.6);renderAll();return}
    if(x=T('[data-ts]')){sel.tstyle=x.dataset.ts;fillInsp();renderAll();return}
    if(x=T('[data-ke]')){sel.kf[ki].e=x.dataset.ke;renderKF();kfSeek();return}
    if(x=T('[data-ea]')){sel.ease=x.dataset.ea;fillInsp();renderAll();return}
    if(x=T('#ratio button')){$$('#ratio button').forEach(b=>b.classList.toggle('on',b===x));state.ratio=x.dataset.r;const st=$('#stage');st.style.aspectRatio=state.ratio;if(state.ratio==='16/9'){st.style.height='auto';st.style.width='100%'}else{st.style.width='auto';st.style.height=state.ratio==='1/1'?'36vh':'42vh'}return}
    if(x=T('.seg:not(#ratio) button')){$$('button',x.parentElement).forEach(b=>b.classList.toggle('on',b===x))}
  });
  $$('.sheet').forEach(s=>s.addEventListener('click',e=>{if(e.target===s)s.classList.remove('on')}));
  $('#intensity').oninput=e=>{state.intensity=+e.target.value;$('#intV').textContent=e.target.value+'%'};
  $('#fxSearch').oninput=e=>{Q=e.target.value.trim();renderCatalog($('#libCats'),$('#fxgrid'))};
  $('#gen').onclick=generate;
  $('#openExport').onclick=()=>openSheet(true);$('#closeSheet').onclick=()=>openSheet(false);$('#doExport').onclick=doExport;
  $('#addFx').onclick=()=>{renderCatalog($('#pickCats'),$('#pickGrid'));$('#pick').classList.add('on')};
  $('#closePick').onclick=()=>$('#pick').classList.remove('on');
  $('#addTitle').onclick=()=>addTitle();
  $('#inClose').onclick=$('#inDone').onclick=()=>$('#insp').classList.remove('on');
  $('#inDel').onclick=()=>{state.events=state.events.filter(v=>v!==sel);$('#insp').classList.remove('on');renderAll()};
  $('#inDup').onclick=()=>{const c={...sel,kf:sel.kf&&sel.kf.map(k=>({...k})),id:state.nid++,t:Math.min(P.dur-.2,sel.t+sel.d)};state.events.push(c);sel=c;fillInsp();renderAll()};
  $('#inTxt').oninput=e=>{sel.label=e.target.value.toUpperCase();renderAll()};
  [['rS','t'],['rD','d'],['rA','amt']].forEach(([id,k])=>$('#'+id).oninput=e=>{sel[k]=+e.target.value;fillInsp();renderAll()});
  const strip=$('#kfStrip'),sp=e=>{const r=strip.getBoundingClientRect();return Math.min(1,Math.max(0,(e.clientX-r.left)/r.width))};
  strip.addEventListener('pointerdown',e=>{if(!isKF(sel))return;const p=sp(e);let best=0,bd=1e9;
    sel.kf.forEach((q,i)=>{const d=Math.abs(q.p-p)*strip.clientWidth;if(d<bd){bd=d;best=i}});
    if(bd<=18){ki=best;kd=sel.kf[best];strip.setPointerCapture(e.pointerId);renderKF();kfSeek()}else{pause();seek(sel.t+p*sel.d)}});
  strip.addEventListener('pointermove',e=>{if(!kd)return;kd.p=sp(e);renderKF();renderTL();pause();seek(sel.t+kd.p*sel.d)});
  const kEnd=()=>{if(!kd)return;sel.kf.sort((a,b)=>a.p-b.p);ki=sel.kf.indexOf(kd);kd=null;renderKF()};
  strip.addEventListener('pointerup',kEnd);strip.addEventListener('pointercancel',kEnd);
  $('#kfSl').addEventListener('input',e=>{const id=e.target.dataset.kp;if(!id||!isKF(sel))return;const k=sel.kf[ki],m=KFP.find(q=>q[0]===id);
    k[id]=+e.target.value;$('#kv-'+id).textContent=Math.round(k[id])+m[2];kfSeek()});
  $('#kfAdd').onclick=()=>{const p=(P.t-sel.t)/sel.d;if(p<0||p>1){toast('Move the playhead inside this clip');return}
    const near=sel.kf.findIndex(q=>Math.abs(q.p-p)<.01);
    if(near>=0)ki=near;else{const v=kfEval(sel.kf,p),n={p,x:v.x,y:v.y,s:v.s,r:v.r,e:'inout'};sel.kf.push(n);sel.kf.sort((a,b)=>a.p-b.p);ki=sel.kf.indexOf(n)}
    renderKF();renderTL()};
  $('#kfDel').onclick=()=>{if(sel.kf.length<2)return;sel.kf.splice(ki,1);ki=Math.max(0,ki-1);renderKF();renderTL();kfSeek()};
  $('#bPlay').onclick=()=>P.playing?pause():play();
  $('#bPrev').onclick=()=>seek(P.t-2);$('#bNext').onclick=()=>seek(P.t+2);
  const send=()=>{const i=$('#askIn'),v=i.value.trim();if(!v)return;i.value='';say(v,'me');revise(v)};
  $('#askBtn').onclick=send;$('#askIn').onkeydown=e=>{if(e.key==='Enter')send()};

  $('#file').onchange=e=>{
    const f=e.target.files[0];if(!f)return;
    const url=URL.createObjectURL(f),v=document.createElement('video');
    v.src=url;v.playsInline=true;v.preload='metadata';
    P.file=f;const ready=()=>{P.dur=Math.max(4,Math.floor(v.duration));P.v=v;$('#media').innerHTML='';$('#media').append(v);if(EC)EC.remove();EC=document.createElement('video');EC.id='echo';EC.src=url;EC.muted=true;EC.playsInline=true;$('#media').after(EC);buildPlan();renderAll();seek(0)};
    v.onloadedmetadata=()=>{if(isFinite(v.duration)&&v.duration>0)ready();else{v.onseeked=()=>{v.onseeked=null;v.currentTime=0;if(isFinite(v.duration)&&v.duration>0)ready();else toast('Could not read the video length. Try an MP4.')};v.currentTime=1e7}};
    v.onended=pause;
    f.arrayBuffer().then(b=>new (window.AudioContext||window.webkitAudioContext)().decodeAudioData(b)).then(a=>{state.beats=beatsOf(a);buildPlan();renderAll();toast(state.beats.length+' beats found. Cuts now land on them.')}).catch(()=>toast('Could not read the audio. Using even beats.'));
    $('#drop').classList.add('has');$('#dropT').textContent=f.name;$('#dropS').textContent=(f.size/1048576).toFixed(1)+' MB · tap to replace';
  };
  const inner=$('#tlin');let drag=false;
  const at=e=>{seek((e.clientX-inner.getBoundingClientRect().left-OFF)/PPS)};
  inner.addEventListener('pointerdown',e=>{at(e);if(e.target.closest('#ruler')){drag=true;inner.setPointerCapture(e.pointerId)}});
  inner.addEventListener('pointermove',e=>{if(drag)at(e)});
  inner.addEventListener('pointerup',()=>drag=false);

  const md=$('#mdraw');
  md.onpointerdown=e=>{if(!MD)return;md.setPointerCapture(e.pointerId);MD=[mdPt(e)]};
  md.onpointermove=e=>{if(!MD||!MD.length)return;MD.push(mdPt(e));$('#mdl').setAttribute('points',MD.map(q=>q.join(',')).join(' '))};
  md.onpointerup=()=>{if(!MD)return;if(MD.length>5){const st=Math.ceil(MD.length/40);addAt('fx','mask','Mask',P.t,3,{pts:MD.filter((_,i)=>i%st===0)});renderAll();toast('Mask added at '+fmt(P.t))}maskMode(false)};
  $('#lyrbar').onclick=e=>{const k=e.target.dataset.ly;if(!k)return;if(k==='add')$('#file2').click();else if(k==='mask')maskMode(true);else if(k==='mode')LB=(LB+1)%BL.length;else if(k==='op')LO=LO<=.4?1:+(LO-.2).toFixed(1);else if(k==='x'){LY.remove();LY=null;P.file2=null}lyrApply();lyrBar()};
  $('#file2').onchange=e=>{const f=e.target.files[0];if(!f)return;P.file2=f;if(LY)LY.remove();LY=document.createElement('video');LY.id='lyr';LY.src=URL.createObjectURL(f);LY.muted=true;LY.playsInline=true;LY.loop=true;$('#media').after(LY);lyrApply();lyrBar();lyrSync();e.target.value=''};
  $('#trkBtn').onclick=()=>{$('#insp').classList.remove('on');trackMask(sel)};
  $('#txtKf').onclick=()=>{if(!sel.kf)sel.kf=KFR({},{s:115});fillInsp();kfSeek();$('main').scrollTo({top:0,behavior:'smooth'})};
  lyrBar();
  $('#addBeat').onclick=()=>{addAt('audio','beat','',P.t,.2);renderAll();toast('Beat marker at '+fmt(P.t))};
  $('#bUndo').onclick=()=>hist(H.u,H.r);$('#bRedo').onclick=()=>hist(H.r,H.u);
  const sv=(()=>{try{return JSON.parse(localStorage.getItem('kino.v1'))}catch(e){return null}})();
  if(sv&&sv.events&&sv.events.length){state.events=sv.events;state.nid=sv.nid||state.events.length+1;P.dur=sv.dur||P.dur;state.style=sv.style||state.style}else buildPlan();
  renderAll();H.u=[];H.r=[];H.last=JSON.stringify(state.events);setPlayIcon();say('Hi! Tell me what to change and I’ll update the edit.','ai');
  requestAnimationFrame(tick);
}
init();
