package app.kino.render;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Evaluates every "fx" event at timeline time T, like compose() in www/app.js.
 * Geometry goes to tx/ty/rot/sx/sy (used by KinoMotion), everything else is packed into vec4s for the shader.
 * CSS px values from the web app are converted with a 375 x 667 stage.
 */
final class KinoFx {
  static final double SW = 375.0, SH = 667.0;

  // geometry: tx, ty in % of the frame, rot in degrees, sx, sy scale
  double tx, ty, rot, sx, sy;
  // shader packs (see kino_effects.frag)
  final float[] a = new float[4];  // grayscale, sepia, invert, hue(deg)
  final float[] b = new float[4];  // brightness, saturation, contrast, black
  final float[] c = new float[4];  // blur, motion blur, -, pixel cell
  final float[] d = new float[4];  // wave, -, -, opacity
  final float[] e = new float[4];  // flash, vignette, grain, scanlines
  final float[] f = new float[4];  // glow, light leak, halftone dots, -
  final float[] g = new float[4];  // multiply, screen, overlay, soft-light tint
  final float[] h = new float[4];  // color-dodge, difference tint, rgb split, echo opacity
  final float[] i = new float[4];  // kaleidoscope segments, kaleidoscope rotation, cube rotation (rad), mode 0/1/2
  boolean echo;

  static double j(double t, double k) { return Math.sin(t * k) * Math.cos(t * k * 0.37); }

  private static String shape(String type) {
    switch (type) {
      case "zoom": case "flip": case "ramp": case "squeeze": case "twist": case "pixel": case "cube": case "fast": case "speed":
      case "rgbf": case "bxf": case "push2": case "blur": case "mblur": case "rblur": case "invert": case "exposure": case "glow":
      case "flash": case "leak": case "rgb": case "tilt": case "dip": case "cross": case "whip": case "zthru": case "spinw": case "glcut":
        return "pulse";
      case "push": case "spin": case "pan": case "roll": case "pop": case "hue": case "fade":
      case "rcircle": case "rwipe": case "rsplit": case "rrect": case "rline":
        return "in";
      case "motion": return "kf";
      default: return "hold";
    }
  }

  private static void mx(float[] arr, int k, double v) { arr[k] = (float) Math.max(arr[k], v); }

  void eval(JSONArray events, double T) {
    tx = ty = rot = 0; sx = sy = 1;
    for (float[] x : new float[][] {a, c, d, e, f, g, h, i}) java.util.Arrays.fill(x, 0f);
    b[0] = 1; b[1] = 1; b[2] = 1; b[3] = 0;
    d[3] = 1;
    echo = false;
    for (int n = 0; n < events.length(); n++) {
      JSONObject ev = events.optJSONObject(n);
      if (ev == null || !"fx".equals(ev.optString("track"))) continue;
      double st = ev.optDouble("t"), dur = ev.optDouble("d", 1);
      if (T < st || T >= st + dur) continue;
      String type = ev.optString("type");
      double p = Math.min(1, Math.max(0, (T - st) / dur));
      String sh = shape(type);
      if ("kf".equals(sh)) { keyframes(ev.optJSONArray("kf"), p); continue; }
      double s = "pulse".equals(sh) ? Math.sin(Math.PI * p) : "in".equals(sh) ? p : Math.min(1, Math.min(p * 8, (1 - p) * 8));
      double amt = (ev.has("amt") ? ev.optDouble("amt") : 70) / 100.0;
      double v = KinoEase.ease(ev.optString("ease", "inout"), s) * amt;
      apply(type, v, p, T, ev, amt);
    }
    if (echo) h[3] = (float) Math.min(h[3], 1);
  }

  private void apply(String type, double v, double p, double T, JSONObject ev, double amt) {
    switch (type) {
      // ---- camera / geometry ----
      case "zoom": sx *= 1 + .3 * v; sy *= 1 + .3 * v; break;
      case "push": sx *= 1 + .25 * v; sy *= 1 + .25 * v; break;
      case "shake":
        tx += j(T, 95) * 16 * v / SW * 100; ty += j(T, 71) * 12 * v / SH * 100; rot += j(T, 53) * 2 * v;
        sx *= 1 + .1 * v; sy *= 1 + .1 * v; break;
      case "spin": rot += 360 * v; sx *= 1.25; sy *= 1.25; break;
      case "pan": tx += (.5 - v) * 16; sx *= 1.3; sy *= 1.3; break;
      case "drift": tx += Math.sin(T * .7) * 3 * v; ty += Math.cos(T * .5) * 2 * v; sx *= 1 + .08 * v; sy *= 1 + .08 * v; break;
      case "swing": rot += Math.sin(T * 3) * 6 * v; sx *= 1.12; sy *= 1.12; break;
      case "orbit": tx += Math.cos(T * 2) * 6 * v; ty += Math.sin(T * 2) * 6 * v; sx *= 1.15; sy *= 1.15; break;
      case "roll": rot += -25 * (1 - v); sx *= 1.2 - .2 * v; sy *= 1.2 - .2 * v; break;
      case "flip": sx *= Math.cos(Math.PI * v); break;
      case "ramp": sx *= 1 + .35 * v; sy *= 1 + .35 * v; mx(c, 0, 6 * v / SW); b[1] *= (float) (1 + .5 * v); break;
      case "squeeze": sx *= 1 + .25 * v; sy *= 1 - .2 * v; break;
      case "twist": rot += 12 * v; sx *= 1.15; sy *= 1.15; break;
      case "tilt3d": sx *= Math.cos(Math.toRadians(Math.sin(T * 1.5) * 28 * v)) * .9; sy *= .9; break;
      case "cube": { double k = 900.0 / (900 + 200 * v); sx *= k * Math.max(.05, Math.cos(Math.PI / 2 * v)); sy *= k; break; }
      case "fast": mx(c, 0, 3 * v / SW); break;
      case "stutter": tx += (Math.floor(T * 12) % 2) * 2 * v; ty += (Math.floor(T * 7) % 2) * -1.5 * v; break;
      case "pop": sx *= .7 + .3 * v; sy *= .7 + .3 * v; break;
      case "rblur": sx *= 1 + .18 * v; sy *= 1 + .18 * v; mx(c, 0, 5 * v / SW); break;
      case "mirror": if (v > .01) sx *= -1; break;
      case "tilt": rot += 9 * v; sx *= 1.15; sy *= 1.15; break;
      case "whip": tx += (p - .5) * -70; sx *= 1.2; sy *= 1.2; mx(c, 0, 10 * v / SW); break;
      case "zthru": sx *= 1 + v; sy *= 1 + v; mx(c, 0, 6 * v / SW); mx(e, 0, .5 * v); break;
      case "spinw": rot += (p - .5) * 120; sx *= 1 + .5 * v; sy *= 1 + .5 * v; mx(c, 0, 4 * v / SW); break;
      case "push2": tx += (p - .5) * -40; mx(c, 0, 5 * v / SW); break;
      // ---- color ----
      case "contrast": b[2] *= (float) (1 + .6 * v); break;
      case "warm": mx(a, 1, .35 * v); b[1] *= (float) (1 + .3 * v); break;
      case "cool": a[3] += (float) (-25 * v); b[1] *= (float) (1 + .2 * v); break;
      case "bw": mx(a, 0, v); break;
      case "sepia": mx(a, 1, v); break;
      case "invert": mx(a, 2, v); break;
      case "hue": a[3] += (float) (360 * v); break;
      case "vivid": b[1] *= (float) (1 + 1.5 * v); b[2] *= (float) (1 + .25 * v); break;
      case "exposure": b[0] *= (float) (1 + .9 * v); break;
      case "fade": b[0] *= (float) Math.max(0, 1 - v); break;
      case "dream": mx(c, 0, 2.5 * v / SW); b[0] *= (float) (1 + .12 * v); b[1] *= (float) (1 + .2 * v); mx(f, 0, .7 * v); break;
      case "neon": b[1] *= (float) (1 + 2 * v); b[2] *= (float) (1 + .2 * v); b[0] *= (float) (1 + .1 * v); mx(f, 0, v); break;
      case "glow": b[0] *= (float) (1 + .15 * v); b[1] *= (float) (1 + .35 * v); mx(f, 0, v); break;
      case "pulse": { double q = Math.abs(Math.sin(T * 6)); b[0] *= (float) (1 + .35 * v * q); mx(f, 0, .5 * v * q); break; }
      case "flicker": b[0] *= (float) Math.max(0, 1 - .5 * v * Math.abs(j(T, 60))); break;
      case "blink": d[3] = (float) Math.min(d[3], 1 - .9 * v * (Math.floor(T * 8) % 2)); break;
      case "ghost": d[3] = (float) Math.min(d[3], 1 - .6 * v); break;
      case "rgbf": a[3] += (float) (120 * v); b[1] *= (float) (1 + v); mx(e, 0, .7 * v); break;
      case "bxf": mx(c, 0, 14 * v / SW); mx(b, 3, .25 * v); break;
      case "blur": mx(c, 0, 12 * v / SW); break;
      case "mblur": mx(c, 1, 28 * v / SW); break;
      case "halftone": b[2] *= (float) (1 + .5 * v); b[1] *= (float) (1 - .4 * v); mx(f, 2, v); break;
      // ---- distort ----
      case "pixel": if (v >= .03) c[3] = (float) Math.max(c[3], Math.max(1, Math.round(14 * v)) * 2 / SW); break;
      case "wave": mx(d, 0, v); break;
      case "kal": i[0] = 2 * Math.round(2 + amt * 3); i[1] = (float) (T * .4); i[3] = 1; break;
      case "box3d": i[2] = (float) Math.toRadians((T - ev.optDouble("t")) * 60 * amt * 100 / 70.0); i[3] = 2; break;
      case "echo": echo = true; h[3] = (float) (.55 * amt); break;
      // ---- glitch / light overlays ----
      case "rgb": mx(h, 2, 6 * v); break;
      case "glitch":
        tx += j(T, 120) * 10 * v / SW * 100; a[3] += (float) (j(T, 40) * 60 * v); b[2] *= (float) (1 + .3 * v); mx(e, 3, .5 * v); break;
      case "glcut":
        tx += j(T, 150) * 20 * v / SW * 100; a[3] += (float) (90 * v); b[2] *= (float) (1 + .5 * v); mx(e, 0, .3 * v); mx(e, 3, v); break;
      case "vhs":
        ty += j(T, 30) * 3 * v / SH * 100; b[1] *= (float) (1 + .4 * v); mx(c, 0, .6 * v / SW); a[3] += (float) (-10 * v);
        mx(e, 3, .8 * v); mx(e, 2, .25 * .5 * v); break;
      case "scan": mx(e, 3, v); break;
      case "grain": mx(e, 2, .25 * v); break;
      case "vig": mx(e, 1, v); break;
      case "flash": mx(e, 0, v); break;
      case "strobe": mx(e, 0, (Math.floor(T * 14) % 2) * v); break;
      case "leak": mx(f, 1, v); break;
      case "dip": mx(b, 3, v); break;
      case "cross": mx(b, 3, .45 * v); break;
      case "bmul": mx(g, 0, v); break;
      case "bscr": mx(g, 1, v); break;
      case "bovl": mx(g, 2, v); break;
      case "bsft": mx(g, 3, v); break;
      case "bdod": mx(h, 0, v); break;
      case "bdif": mx(h, 1, v); break;
      default: break; // masks, freeze, speed: handled elsewhere
    }
  }

  /** Keyframe motion, same maths as kfEval() in www/app.js. */
  private void keyframes(JSONArray kf, double p) {
    if (kf == null || kf.length() == 0) return;
    JSONObject lo = kf.optJSONObject(0), hi = kf.optJSONObject(kf.length() - 1);
    if (lo == null || hi == null) return;
    if (p <= lo.optDouble("p")) hi = lo;
    else if (p >= hi.optDouble("p")) lo = hi;
    else for (int k = 0; k < kf.length() - 1; k++) {
      JSONObject c0 = kf.optJSONObject(k), c1 = kf.optJSONObject(k + 1);
      if (c0 != null && c1 != null && p >= c0.optDouble("p") && p <= c1.optDouble("p")) { lo = c0; hi = c1; break; }
    }
    double span = hi.optDouble("p") - lo.optDouble("p");
    double u = span > 0 ? KinoEase.ease(hi.optString("e", "inout"), (p - lo.optDouble("p")) / span) : 1;
    tx += lo.optDouble("x") + (hi.optDouble("x") - lo.optDouble("x")) * u;
    ty += lo.optDouble("y") + (hi.optDouble("y") - lo.optDouble("y")) * u;
    double s = (lo.optDouble("s", 100) + (hi.optDouble("s", 100) - lo.optDouble("s", 100)) * u) / 100.0;
    sx *= s; sy *= s;
    rot += lo.optDouble("r") + (hi.optDouble("r") - lo.optDouble("r")) * u;
  }
}
