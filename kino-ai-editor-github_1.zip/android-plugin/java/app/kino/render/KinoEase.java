package app.kino.render;

/** Same easing curves as EASE in www/app.js. */
final class KinoEase {
  private KinoEase() {}

  static double ease(String e, double x) {
    if (e == null) e = "inout";
    switch (e) {
      case "linear": return x;
      case "scurve": return x * x * (3 - 2 * x);
      case "expo": return x >= 1 ? 1 : 1 - Math.pow(2, -10 * x);
      case "step": return Math.floor(x * 4) / 4;
      case "hold": return x < 1 ? 0 : 1;
      case "in": return x * x;
      case "out": return 1 - (1 - x) * (1 - x);
      case "bounce": return bounce(x);
      case "elastic": return x <= 0 ? 0 : x >= 1 ? 1 : Math.pow(2, -10 * x) * Math.sin((x * 10 - 0.75) * 2.0944) + 1;
      case "back": return 1 + 2.7 * Math.pow(x - 1, 3) + 1.7 * Math.pow(x - 1, 2);
      default: return x < 0.5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2;
    }
  }

  private static double bounce(double x) {
    double n = 7.5625, d = 2.75;
    if (x < 1 / d) return n * x * x;
    if (x < 2 / d) { x -= 1.5 / d; return n * x * x + 0.75; }
    if (x < 2.5 / d) { x -= 2.25 / d; return n * x * x + 0.9375; }
    x -= 2.625 / d;
    return n * x * x + 0.984375;
  }
}
