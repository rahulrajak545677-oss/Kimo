package app.kino.render;

import android.content.Context;
import android.graphics.Bitmap;
import android.opengl.GLES20;
import android.opengl.GLUtils;
import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.GlProgram;
import androidx.media3.common.util.GlUtil;
import androidx.media3.common.util.Size;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.BaseGlShaderProgram;
import java.io.IOException;
import org.json.JSONArray;

/** Runs kino_effects.frag per frame. All effect values come from KinoFx, masks and titles are bitmaps drawn per frame. */
@UnstableApi
final class KinoShader extends BaseGlShaderProgram {
  private final GlProgram program;
  private final JSONArray events;
  private final KinoClock clock;
  private final KinoRemap remap;
  private final KinoMask mask;
  private final KinoTitle title = new KinoTitle();
  private final KinoFx fx = new KinoFx();
  private final KinoLayer layer2, echoLayer;
  private final int blend;
  private final float opacity;
  private int outW = 1080, outH = 1920;
  private int layerTex, echoTex, maskTex, titleTex;
  private boolean texReady;
  private int layerVer = -1, echoVer = -1;

  KinoShader(Context ctx, JSONArray events, KinoClock clock, KinoRemap remap, KinoMask mask, KinoLayer layer2, KinoLayer echoLayer,
             int blend, float opacity) throws VideoFrameProcessingException {
    super(/* useHighPrecisionColorComponents= */ false, /* texturePoolCapacity= */ 1);
    this.events = events;
    this.clock = clock;
    this.remap = remap;
    this.mask = mask;
    this.layer2 = layer2;
    this.echoLayer = echoLayer;
    this.blend = blend;
    this.opacity = opacity;
    try {
      program = new GlProgram(ctx, "shaders/kino_vertex.glsl", "shaders/kino_effects.frag");
    } catch (IOException | GlUtil.GlException e) {
      throw new VideoFrameProcessingException(e);
    }
    program.setBufferAttribute("aFramePosition", GlUtil.getNormalizedCoordinateBounds(),
        GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE);
  }

  @Override public Size configure(int w, int h) {
    outW = w;
    outH = h;
    return new Size(w, h);
  }

  @Override public void release() throws VideoFrameProcessingException {
    super.release();
    try {
      if (texReady) GLES20.glDeleteTextures(4, new int[] {layerTex, echoTex, maskTex, titleTex}, 0);
      program.delete();
    } catch (GlUtil.GlException e) {
      throw new VideoFrameProcessingException(e);
    }
  }

  private static int newTex() {
    int[] t = new int[1];
    GLES20.glGenTextures(1, t, 0);
    GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0]);
    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
    return t[0];
  }

  private static void upload(int tex, Bitmap b) {
    GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex);
    GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, b, 0);
  }

  private void initTextures() {
    if (texReady) return;
    layerTex = newTex();
    echoTex = newTex();
    maskTex = newTex();
    titleTex = newTex();
    Bitmap one = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
    upload(layerTex, one);
    upload(echoTex, one);
    upload(maskTex, one);
    upload(titleTex, one);
    texReady = true;
  }

  @Override public void drawFrame(int tex, long ptsUs) throws VideoFrameProcessingException {
    double t = clock.at(ptsUs);
    fx.eval(events, t);
    try {
      initTextures();
      Bitmap mb = mask.draw(t, outW, outH);
      if (mb != null) upload(maskTex, mb);
      Bitmap tb = title.draw(events, t, outW, outH);
      if (tb != null) upload(titleTex, tb);

      float[] ls = null;
      if (layer2 != null && layer2.ok()) {
        if (layer2.frame(t) != null) {
          if (layerVer != layer2.version()) { upload(layerTex, layer2.frame(t)); layerVer = layer2.version(); }
          ls = layer2.coverScale(outW, outH);
        }
      }
      float[] es = null;
      if (fx.echo && echoLayer != null && echoLayer.ok()) {
        Bitmap eb = echoLayer.frame(remap.srcT(Math.max(0, t - 0.3)));
        if (eb != null) {
          if (echoVer != echoLayer.version()) { upload(echoTex, eb); echoVer = echoLayer.version(); }
          es = echoLayer.coverScale(outW, outH);
        }
      }

      program.use();
      program.setSamplerTexIdUniform("uTexSampler", tex, 0);
      program.setSamplerTexIdUniform("uLayer", layerTex, 1);
      program.setSamplerTexIdUniform("uMaskTex", maskTex, 2);
      program.setSamplerTexIdUniform("uTitleTex", titleTex, 3);
      program.setSamplerTexIdUniform("uEchoTex", echoTex, 4);
      program.setFloatUniform("uMaskOn", mb != null ? 1f : 0f);
      program.setFloatUniform("uTitleOn", tb != null ? 1f : 0f);
      program.setFloatUniform("uLayerOn", ls != null ? 1f : 0f);
      program.setFloatUniform("uEchoOn", es != null ? 1f : 0f);
      program.setFloatUniform("uLayerOp", opacity);
      program.setFloatUniform("uBlend", (float) blend);
      program.setFloatsUniform("uLayerScale", ls != null ? ls : new float[] {1f, 1f});
      program.setFloatsUniform("uEchoScale", es != null ? es : new float[] {1f, 1f});
      program.setFloatsUniform("uA", fx.a);
      program.setFloatsUniform("uB", fx.b);
      program.setFloatsUniform("uC", fx.c);
      program.setFloatsUniform("uD", fx.d);
      program.setFloatsUniform("uE", fx.e);
      program.setFloatsUniform("uF", fx.f);
      program.setFloatsUniform("uG", fx.g);
      program.setFloatsUniform("uH", fx.h);
      program.setFloatsUniform("uI", fx.i);
      program.setFloatsUniform("uJ", new float[] {outW, outH, 2.4f * outW, (float) t});
      program.bindAttributesAndUniforms();
      GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
    } catch (GlUtil.GlException e) {
      throw new VideoFrameProcessingException(e, ptsUs);
    }
  }
}
