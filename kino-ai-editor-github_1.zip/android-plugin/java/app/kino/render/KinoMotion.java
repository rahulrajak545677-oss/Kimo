package app.kino.render;

import android.graphics.Matrix;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.MatrixTransformation;
import org.json.JSONArray;

/** Camera effects, keyframe motion, shake, spin, zoom, whip and so on as one matrix per frame (see KinoFx for the maths). */
@UnstableApi
final class KinoMotion implements MatrixTransformation {
  private final JSONArray events;
  private final KinoClock clock;
  private final KinoFx fx = new KinoFx();
  private volatile float aspect = 9f / 16f;

  KinoMotion(JSONArray events, KinoClock clock) {
    this.events = events;
    this.clock = clock;
  }

  public boolean isNoOp(int inputWidth, int inputHeight) {
    if (inputWidth > 0 && inputHeight > 0) aspect = (float) inputWidth / inputHeight;
    return false;
  }

  @Override
  public Matrix getMatrix(long presentationTimeUs) {
    fx.eval(events, clock.at(presentationTimeUs));
    float a = aspect;
    Matrix m = new Matrix();
    m.postScale((float) fx.sx, (float) fx.sy);
    // NDC is squashed on non-square frames, so rotate in square space: x * aspect, rotate, back.
    m.postScale(a, 1f);
    m.postRotate((float) -fx.rot);
    m.postScale(1f / a, 1f);
    m.postTranslate((float) (fx.tx / 50.0), (float) (-fx.ty / 50.0));
    return m;
  }
}
