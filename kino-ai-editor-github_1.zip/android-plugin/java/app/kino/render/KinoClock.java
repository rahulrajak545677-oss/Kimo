package app.kino.render;

/**
 * Turns the presentation time an effect receives into timeline time.
 * Plain export: timeline time is the timestamp itself. Remapped export: every segment starts at its own timeline
 * offset, and the first timestamp seen counts as the segment start, so it works whether Media3 hands effects
 * item-relative or sequence-wide timestamps.
 */
final class KinoClock {
  private final double startT;
  private final boolean absolute;
  private long firstUs = Long.MIN_VALUE;

  private KinoClock(double startT, boolean absolute) { this.startT = startT; this.absolute = absolute; }

  static KinoClock absolute() { return new KinoClock(0, true); }

  static KinoClock segment(double startT) { return new KinoClock(startT, false); }

  double at(long ptsUs) {
    if (absolute) return ptsUs / 1e6;
    if (firstUs == Long.MIN_VALUE) firstUs = ptsUs;
    return startT + (ptsUs - firstUs) / 1e6;
  }
}
