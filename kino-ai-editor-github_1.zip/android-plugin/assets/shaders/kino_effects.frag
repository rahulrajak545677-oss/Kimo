#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 vTexSamplingCoord;
uniform sampler2D uTexSampler;  // main video
uniform sampler2D uLayer;       // second layer frame
uniform sampler2D uEchoTex;     // delayed copy of the main clip (Echo)
uniform sampler2D uMaskTex;     // reveal / free-draw mask (white = keep)
uniform sampler2D uTitleTex;    // title, premultiplied alpha
uniform float uLayerOn, uLayerOp, uBlend, uMaskOn, uTitleOn, uEchoOn;
uniform vec2 uLayerScale;       // visible fraction of the layer frame (cover fit)
uniform vec2 uEchoScale;
// packed effect values, see KinoFx.java
uniform vec4 uA;  // grayscale, sepia, invert, hue (deg)
uniform vec4 uB;  // brightness, saturation, contrast, black
uniform vec4 uC;  // blur, motion blur, -, pixel cell (fraction of width)
uniform vec4 uD;  // wave, -, -, opacity
uniform vec4 uE;  // flash, vignette, grain, scanlines
uniform vec4 uF;  // glow, light leak, halftone dots, -
uniform vec4 uG;  // multiply, screen, overlay, soft-light tint
uniform vec4 uH;  // color-dodge, difference tint, rgb split, echo opacity
uniform vec4 uI;  // kaleidoscope segments, kaleidoscope rotation, cube rotation, mode (0 none, 1 kaleidoscope, 2 cube)
uniform vec4 uJ;  // width, height, cube distance, time

float hash(vec2 p){return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);}

vec3 hardlight(vec3 b, vec3 s){
  return mix(2.0 * b * s, 1.0 - 2.0 * (1.0 - b) * (1.0 - s), step(0.5, s));
}
vec3 softlight(vec3 b, vec3 s){
  vec3 d = mix(((16.0 * b - 12.0) * b + 4.0) * b, sqrt(b), step(0.25, b));
  return mix(b - (1.0 - 2.0 * s) * b * (1.0 - b), b + (2.0 * s - 1.0) * (d - b), step(0.5, s));
}
vec3 screenB(vec3 b, vec3 s){return 1.0 - (1.0 - b) * (1.0 - s);}
vec3 dodgeB(vec3 b, vec3 s){return min(vec3(1.0), b / max(vec3(1.0) - s, vec3(0.001)));}
// order matches BL in www/app.js: normal, screen, multiply, overlay, soft-light, lighten, difference, hard-light, color-dodge
vec3 blendMode(vec3 b, vec3 s){
  if (uBlend < 0.5) return s;
  if (uBlend < 1.5) return screenB(b, s);
  if (uBlend < 2.5) return b * s;
  if (uBlend < 3.5) return hardlight(s, b);
  if (uBlend < 4.5) return softlight(b, s);
  if (uBlend < 5.5) return max(b, s);
  if (uBlend < 6.5) return abs(b - s);
  if (uBlend < 7.5) return hardlight(b, s);
  return dodgeB(b, s);
}

// ---------- sampling ----------
vec3 vid(vec2 uv){
  float o = uH.z * 0.01;
  return vec3(texture2D(uTexSampler, uv + vec2(o, 0.0)).r,
              texture2D(uTexSampler, uv).g,
              texture2D(uTexSampler, uv - vec2(o, 0.0)).b);
}

// kaleidoscope: wedges mirrored around the centre, same layout as kalDraw() in app.js
vec2 kalUV(vec2 uv){
  vec2 res = uJ.xy;
  vec2 P = vec2((uv.x - 0.5) * res.x, (0.5 - uv.y) * res.y);
  float a = 6.2831853 / max(uI.x, 2.0);
  float phi = atan(P.y, P.x);
  if (phi < 0.0) phi += 6.2831853;
  float i = floor(phi / a);
  float psi = (mod(i, 2.0) < 0.5) ? phi - i * a : (i + 1.0) * a - phi;
  vec2 l = length(P) * vec2(cos(psi), sin(psi));
  float cr = cos(uI.y), sr = sin(uI.y);
  vec2 q = vec2(cr * l.x + sr * l.y, -sr * l.x + cr * l.y);
  return vec2(0.5 + q.x / res.x, 0.5 - q.y / res.y);
}

// 3D cube: four side faces with perspective, same geometry as cubeDrawC() in app.js
vec3 cubeAt(vec2 uv){
  float W = uJ.x, H = uJ.y, d = uJ.z;
  float X = (uv.x - 0.5) * W, Y = (0.5 - uv.y) * H;
  for (int k = 0; k < 4; k++) {
    float f = uI.z + float(k) * 1.5707963;
    float nx = sin(f), nz = cos(f);
    if (nz > 0.0) {
      float a = nx * W * 0.5, b = W * cos(f), c0 = nz * W * 0.5 - W * 0.5, e = W * sin(f);
      float den = X * e - d * b;
      if (abs(den) > 0.0001) {
        float u = (d * a - X * (d - c0)) / den;
        if (abs(u) <= 0.5) {
          float z = c0 - u * e;
          float s = d / (d - z);
          float v = Y / (H * s);
          if (abs(v) <= 0.5) return vid(vec2(u + 0.5, 0.5 - v));
        }
      }
    }
  }
  return vec3(0.0);
}

vec3 baseAt(vec2 uv){
  if (uI.w > 1.5) return cubeAt(uv);
  if (uI.w > 0.5) return vid(kalUV(uv));
  return vid(uv);
}

vec2 warp(vec2 uv){
  if (uC.w > 0.0) {
    vec2 n = vec2(1.0 / uC.w, (uJ.y / uJ.x) / uC.w);
    uv = (floor(uv * n) + 0.5) / n;
  }
  if (uD.x > 0.0) uv.x += sin(uv.y * 30.0 + uJ.w * 8.0) * 0.05 * uD.x;
  return uv;
}

vec3 sceneAt(vec2 uv){
  vec2 q = warp(uv);
  float r = uC.x;
  float m = uC.y;
  if (r < 0.0005 && m < 0.0005) return baseAt(q);
  vec2 asp = vec2(1.0, uJ.x / uJ.y);
  vec3 acc = baseAt(q);
  float w = 1.0;
  if (r >= 0.0005) {
    for (int k = 0; k < 12; k++) {
      float ang = float(k) * 0.5236;              // 12 taps on two rings
      float rad = (mod(float(k), 2.0) < 0.5) ? 0.5 : 1.0;
      acc += baseAt(q + vec2(cos(ang), sin(ang)) * rad * r * asp);
      w += 1.0;
    }
  } else {
    for (int k = -4; k <= 4; k++) {
      if (k == 0) continue;
      acc += baseAt(q + vec2(float(k) * 0.5 * m, 0.0));   // horizontal streak, +/- 2 sigma
      w += 1.0;
    }
  }
  return acc / w;
}

// ---------- overlays ----------
vec3 stops3(float t, vec3 c0, vec3 c1, vec3 c2, float s1){
  return t < s1 ? mix(c0, c1, t / s1) : mix(c1, c2, (t - s1) / (1.0 - s1));
}

void main() {
  vec2 uv = vTexSamplingCoord;
  vec2 fuv = vec2(uv.x, 1.0 - uv.y);   // bitmap textures are top-down
  float W = uJ.x, H = uJ.y;
  vec2 P = vec2(uv.x * W, (1.0 - uv.y) * H);   // canvas pixels, y down

  vec3 c = sceneAt(uv);

  // colour grade (CSS filter order)
  c = mix(c, vec3(dot(c, vec3(0.299, 0.587, 0.114))), uA.x);                                       // grayscale
  vec3 sp = vec3(dot(c, vec3(0.393, 0.769, 0.189)), dot(c, vec3(0.349, 0.686, 0.168)), dot(c, vec3(0.272, 0.534, 0.131)));
  c = mix(c, min(sp, vec3(1.0)), uA.y);                                                           // sepia
  c = mix(c, 1.0 - c, uA.z);                                                                      // invert
  if (abs(uA.w) > 0.01) {                                                                         // hue rotate
    float ca = cos(radians(uA.w)), sa = sin(radians(uA.w));
    mat3 hr = mat3(0.213 + ca * 0.787 - sa * 0.213, 0.213 - ca * 0.213 + sa * 0.143, 0.213 - ca * 0.213 - sa * 0.787,
                   0.715 - ca * 0.715 - sa * 0.715, 0.715 + ca * 0.285 + sa * 0.140, 0.715 - ca * 0.715 + sa * 0.715,
                   0.072 - ca * 0.072 + sa * 0.928, 0.072 - ca * 0.072 - sa * 0.283, 0.072 + ca * 0.928 + sa * 0.072);
    c = clamp(hr * c, 0.0, 1.0);
  }
  c *= uB.x;                                                                                      // brightness
  c = (c - 0.5) * uB.z + 0.5;                                                                     // contrast
  float l = dot(c, vec3(0.299, 0.587, 0.114));
  c = mix(vec3(l), c, uB.y);                                                                      // saturation
  c = clamp(c, 0.0, 1.0);
  c = mix(vec3(0.0), c, uD.w);                                                                    // opacity (blink, ghost)

  if (uMaskOn > 0.5) c *= texture2D(uMaskTex, fuv).r;

  // echo: delayed copy on top, screen blend
  if (uEchoOn > 0.5) {
    vec3 E = texture2D(uEchoTex, (fuv - 0.5) * uEchoScale + 0.5).rgb;
    c = mix(c, screenB(c, E), uH.w);
  }
  // second layer with blend mode
  if (uLayerOn > 0.5) {
    vec3 L = texture2D(uLayer, (fuv - 0.5) * uLayerScale + 0.5).rgb;
    c = mix(c, blendMode(c, L), uLayerOp);
  }

  // flash, black, vignette
  c = mix(c, vec3(1.0), clamp(uE.x, 0.0, 1.0));
  c = mix(c, vec3(0.0), clamp(uB.w, 0.0, 1.0));
  float dist = distance(uv, vec2(0.5));
  c *= 1.0 - uE.y * smoothstep(0.35, 0.9, dist);

  // tint overlays with blend modes (colours as in OV2 in app.js)
  if (uG.x > 0.0) {   // multiply, linear (0.3W,0)->(0.7W,H)
    vec2 d = vec2(0.4 * W, H);
    float t = clamp(dot(P - vec2(0.3 * W, 0.0), d) / dot(d, d), 0.0, 1.0);
    c = mix(c, c * mix(vec3(1.0, 0.702, 0.420), vec3(0.478, 0.361, 1.0), t), min(1.0, uG.x));
  }
  if (uG.y > 0.0) {   // screen, radial at (0.7W,0.3H)
    float t = clamp(distance(P, vec2(0.7 * W, 0.3 * H)) / (max(W, H) * 0.8), 0.0, 1.0);
    vec3 g = t < 0.55 ? mix(vec3(0.498, 0.839, 1.0), vec3(1.0, 0.416, 0.835), t / 0.55) : vec3(1.0, 0.416, 0.835);
    float al = t < 0.55 ? 1.0 : 1.0 - (t - 0.55) / 0.45;
    c = mix(c, screenB(c, g), min(1.0, uG.y) * al);
  }
  if (uG.z > 0.0) {   // overlay, vertical teal -> orange
    vec3 g = mix(vec3(0.0, 0.761, 0.780), vec3(1.0, 0.478, 0.094), clamp(P.y / H, 0.0, 1.0));
    c = mix(c, hardlight(g, c), min(1.0, uG.z));
  }
  if (uG.w > 0.0) {   // soft light, horizontal pink -> peach
    vec3 g = mix(vec3(1.0, 0.620, 0.796), vec3(1.0, 0.839, 0.627), clamp(P.x / W, 0.0, 1.0));
    c = mix(c, softlight(c, g), min(1.0, uG.w));
  }
  if (uH.x > 0.0) {   // color dodge, radial warm highlight at (0.5W,0.4H)
    float t = clamp(distance(P, vec2(0.5 * W, 0.4 * H)) / (max(W, H) * 0.7), 0.0, 1.0);
    vec3 g = t < 0.6 ? mix(vec3(1.0, 0.949, 0.8), vec3(1.0, 0.541, 0.298), t / 0.6) : vec3(1.0, 0.541, 0.298);
    float al = t < 0.6 ? 1.0 : 1.0 - (t - 0.6) / 0.4;
    c = mix(c, dodgeB(c, g), min(1.0, uH.x) * al);
  }
  if (uH.y > 0.0) {   // difference, horizontal blue -> mint
    vec3 g = mix(vec3(0.227, 0.0, 1.0), vec3(0.0, 1.0, 0.639), clamp(P.x / W, 0.0, 1.0));
    c = mix(c, abs(c - g), min(1.0, uH.y));
  }
  if (uF.y > 0.0) {   // light leak, diagonal, screen
    vec2 d = vec2(W, H);
    float t = clamp(dot(P, d) / dot(d, d), 0.0, 1.0);
    vec3 g = t < 0.45 ? mix(vec3(1.0, 0.471, 0.157), vec3(1.0, 0.235, 0.471), t / 0.45) : vec3(1.0, 0.235, 0.471);
    float al = t < 0.45 ? mix(0.95, 0.4, t / 0.45) : mix(0.4, 0.0, clamp((t - 0.45) / 0.25, 0.0, 1.0));
    c = mix(c, screenB(c, g), min(1.0, uF.y) * al);
  }
  if (uF.x > 0.0) {   // glow: gold vignette ring
    float t = smoothstep(min(W, H) * 0.4, length(vec2(W, H)) * 0.5, distance(P, vec2(0.5 * W, 0.5 * H)));
    c = mix(c, vec3(0.914, 0.812, 0.576), 0.85 * t * min(1.0, uF.x));
  }
  if (uF.z > 0.0) {   // halftone dots, multiply
    float cell = 7.0 * W / 540.0;
    vec2 q = fract(P / cell) - 0.5;
    float dot_ = 1.0 - smoothstep(2.5 / 7.0 - 0.04, 2.5 / 7.0 + 0.04, length(q));
    c = mix(c, c * (1.0 - dot_), min(1.0, uF.z));
  }
  if (uE.w > 0.0) {   // scanlines
    float row = step(0.75, fract(P.y / (4.0 * W / 540.0)));
    c *= 1.0 - 0.4 * row * min(1.0, uE.w);
  }
  c += (hash(uv * 1000.0 + uJ.w) - 0.5) * uE.z;   // grain

  if (uTitleOn > 0.5) {
    vec4 T = texture2D(uTitleTex, fuv);
    c = T.rgb + c * (1.0 - T.a);
  }
  gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
