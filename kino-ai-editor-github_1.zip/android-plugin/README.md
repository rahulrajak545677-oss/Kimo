# Native render (written, not compiled or tested)
Files are in `java/app/kino/render/` (KinoRenderPlugin, KinoShader, KinoFx, KinoMotion, KinoRemap, KinoLayer, KinoClock, KinoMask, KinoTitle, KinoEase) and `assets/shaders/`.
Files: `java/app/kino/render/KinoRenderPlugin.java`, `KinoShader.java`, `KinoMotion.java`, `assets/shaders/kino_vertex.glsl`, `assets/shaders/kino_effects.frag`.

Setup in Android Studio after `npx cap add android` and `npm install`:
1. Copy `java/app/kino/render/*` into `android/app/src/main/java/app/kino/render/` and `assets/shaders/*` into `android/app/src/main/assets/shaders/`.
2. In `android/app/build.gradle` add: `implementation 'androidx.media3:media3-transformer:1.4.1'`, `'androidx.media3:media3-effect:1.4.1'`, `'androidx.media3:media3-common:1.4.1'`.
3. In `MainActivity.onCreate`, before `super.onCreate`, call `registerPlugin(app.kino.render.KinoRenderPlugin.class);`.
4. `npx cap sync android`, build, run. Media3 API names can differ by version, so expect to fix small compile errors.

How it connects: Export copies the picked video into the app cache with `@capacitor/filesystem`, calls `KinoRender.render({src, out, events, height, fps})`,
and falls back to the web recording if the plugin is missing or fails. The native pass renders RGB split, vignette, grain, flash, contrast and saturation
from `state.events` on the timeline clock. Keyframe motion (position, scale, rotation with ease) is native too, via `KinoMotion`.

Also native now (new, uncompiled):
- **Masks** (`KinoMask`): free-draw mask with tracking, plus circle, wipe, split, rectangle and line reveals. Drawn on the CPU each frame, shown through a texture.
- **Second layer + blend modes**: pass `layer2Src`, `blend` (index into BL in app.js) and `opacity`. Frames come from `MediaMetadataRetriever`, so this part is slow
  (expect an export of a 30 s clip to take a few minutes). The shader has normal, screen, multiply, overlay, soft-light, lighten, difference, hard-light, color-dodge.
- **Titles** (`KinoTitle`): all 8 animations and 4 styles from the title inspector.

## Now native too (new, uncompiled)
- **All shader effects**: colour (B&W, sepia, invert, hue, exposure, fade, warm, cool, vivid, contrast), blur (gaussian, motion, zoom), pixelate, wave, halftone,
  glow, neon, dreamy, light leak, scanlines, VHS, glitch, flash, strobe, dip, dissolve, flicker, blink, ghost, and the six blend tints. Values come from `KinoFx`,
  which mirrors `compose()` in `www/app.js`.
- **Camera effects** (zoom, push, shake, spin, pan, drift, swing, orbit, roll, tilt, pop, whip, zoom through, spin wipe, push slide, mirror, 3D tilt, flip) go through
  the matrix in `KinoMotion`, aspect-corrected. Skew parts of twist/glitch/3D tilt are approximated (scale + rotation only).
- **Kaleidoscope** and the **3D cube** (four side faces, as in the web export) are drawn in the shader.
- **Echo**: delayed copy at source time `srcT(t - 0.3)`, screen blended, frames from `MediaMetadataRetriever` (slow while echo is active).
- **Freeze frame, Speed ramp, Speed up** (`KinoRemap`): the timeline is cut into freeze pieces (a PNG of the held frame as an image item) and constant-speed pieces
  (0.1 s steps for ramps, `SpeedChangeEffect` + `SonicAudioProcessor`), joined in one `EditedMediaItemSequence`. Each piece has a `KinoClock`, so effects, masks and titles
  still use timeline time.

Fixed while adding these: the shader used to be constructed on the UI thread, which has no GL context. It is now created inside the `GlEffect`, on Media3's GL thread.

Things most likely to need a fix after the first build: `SpeedChangeEffect`, `EditedMediaItem.Builder.setDurationUs/setFrameRate`,
`Composition.Builder.experimentalSetForceAudioTrack`, `MatrixTransformation.isNoOp`. Send me the errors.
Remaining approximations: masks use a 540 px image (soft edges), rounded-rectangle corners, skew in twist/glitch/3D tilt, grain strength, blur is a 12-tap approximation.
